<?php
/*
Description: assets.php
Author: AD-THEME
*/


add_action('wp_enqueue_scripts', 'wpfastslider_frontend_scripts');

function wpfastslider_frontend_scripts() {
	
	wp_enqueue_script('jquery');
	wp_register_script('slippry.min.js', ADT_FS_URL . 'assets/js/slippry.min.js', array('jquery'), '', true);
	
}


add_action( 'wp_enqueue_scripts', 'wpfastslider_frontend_styles' );

function wpfastslider_frontend_styles() {
	
	wp_register_style( 'slippry.css',  ADT_FS_URL . 'assets/css/slippry.css' );
	wp_register_style( 'style.css',  ADT_FS_URL . 'assets/css/style.css' );
	wp_register_style( 'animations.css',  ADT_FS_URL . 'assets/css/animations.css' );
	
}


?>