<?php
/*
Description: metabox-functions.php
Author: AD-THEME
*/

/**
 * Adds the meta box stylesheet when appropriate
 */
function adtheme_fastslider_admin_style(){
	global $typenow;
	if( $typenow == 'adt_fastslider' ) {
		/* USE FUTURE */
	}
}
add_action( 'admin_enqueue_scripts', 'adtheme_fastslider_admin_style' );


/**
 * Loads the image management javascript
 */
function adtheme_fastslider_image_enqueue() {
	global $typenow;
	if( $typenow == 'adt_fastslider' ) {
		wp_enqueue_media();
    	wp_enqueue_script('thickbox');
    	wp_enqueue_style('thickbox');
		wp_enqueue_script('jquery-ui-sortable');
		wp_enqueue_style( 'wp-color-picker');
		wp_enqueue_script( 'wp-color-picker');				
		wp_register_script( 'adtheme-fastslider-metabox-image', plugin_dir_url( __FILE__ ) . 'metabox-image-upload.js', array( 'jquery' ) );
		wp_localize_script( 'adtheme-fastslider-metabox-image', 'meta_image',
			array(
				'title' => __( 'Choose or Upload an Image', 'fastslider' ),
				'button' => __( 'Use this image', 'fastslider' ),
			)
		);
		wp_enqueue_script( 'adtheme-fastslider-metabox-image' );
	}
}
add_action( 'admin_enqueue_scripts', 'adtheme_fastslider_image_enqueue' );