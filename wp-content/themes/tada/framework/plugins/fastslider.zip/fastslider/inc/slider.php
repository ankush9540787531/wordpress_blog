<?php
/*
Description: slider.php
Author: AD-THEME
*/

function adt_fastslider ( $attr ) {
		$id = $attr['id'];
		static $instance;
		$instance++;
		// QUERY BY ID //
		
		$query = array(
			'p' => $id,
			'post_type' => 'adt_fastslider',
		);
		
		$adt_fastslider_loop = new WP_Query($query);
		if($adt_fastslider_loop) { 
		while ( $adt_fastslider_loop->have_posts() ) : $adt_fastslider_loop->the_post();
	
		/* LOADE JS/CSS FILES */
		
		wp_enqueue_script('slippry.min.js');
		wp_enqueue_style( 'animations.css' );	
		wp_enqueue_style( 'style.css' );
		wp_enqueue_style( 'slippry.css' );
		
		/* LOAD METABOX */
		$adt_fastslider_bg_color_pattern 		= get_post_meta( get_the_ID(), 'adt_fastslider_bg_color_pattern', true );
		$adt_fastslider_bg_opacity_pattern 		= get_post_meta( get_the_ID(), 'adt_fastslider_bg_opacity_pattern', true );
		$adt_fastslider_color_np 				= get_post_meta( get_the_ID(), 'adt_fastslider_color_np', true );
		$adt_fastslider_navigation_style 		= get_post_meta( get_the_ID(), 'adt_fastslider_navigation_style', true );
		$adt_fastslider_pagination_style 		= get_post_meta( get_the_ID(), 'adt_fastslider_pagination_style', true );
		$adt_fastslider_preload_bg_color 		= get_post_meta( get_the_ID(), 'adt_fastslider_preload_bg_color', true );
		$adt_fastslider_preload_spinner_color 	= get_post_meta( get_the_ID(), 'adt_fastslider_preload_spinner_color', true );
		$adt_fastslider_transition 				= get_post_meta( get_the_ID(), 'adt_fastslider_transition', true );
		
		if($adt_fastslider_bg_opacity_pattern == '') { $adt_fastslider_bg_opacity_pattern = '0.6'; }
		if($adt_fastslider_transition == 'vertical') { $adt_fastslider_transition_class = 'adt-fastslider-vertical'; } else { $adt_fastslider_transition_class = ''; }
		$fastslider_options = get_post_meta( get_the_ID(), 'fastslider_options' );
		$slides = get_post_meta( get_the_ID(), 'slides' );
		
		$return = '';
		
		$return .= adt_custom_code(	$instance,
									get_post_meta( get_the_ID(), 'adt_fastslider_custom_css', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_custom_js', true )
									);
		
		
		$return .= adt_fastslider_js($instance,
									get_post_meta( get_the_ID(), 'adt_fastslider_transition', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_speed', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_pause', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_preload', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_autohover', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_pagination', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_navigation', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_autoplay', true ),
									get_post_meta( get_the_ID(), 'adt_fastslider_loop', true )
									);
									
		/******************************/
		/******* SLYLE SLIDER *********/
		/******************************/
		
		/* GET COLOR NAVIGATION AND PAGINATION */
		$adt_fastslider_color_np = get_post_meta( get_the_ID(), 'adt_fastslider_color_np', true );
		$adt_fastslider_color_np_rgba = adt_fastslider_shex2rgb($adt_fastslider_color_np);

		$adt_fastslider_color_np_bg_with_opacity = 'rgba( '.$adt_fastslider_color_np_rgba[0].' , '.$adt_fastslider_color_np_rgba[1].' , '.$adt_fastslider_color_np_rgba[2].' , 0.6)'; 

		$return .= '<style>';
		$return .= '.adt-fastslider-container-'.$instance.' .sy-controls li.sy-prev a:after, 
					.adt-fastslider-container-'.$instance.' .sy-controls li.sy-next a:after { 
						background-color:'.$adt_fastslider_color_np_bg_with_opacity.'!important;
						transition: background-color 0.3s ease 0s; 
					}
					.adt-fastslider-container-'.$instance.' .sy-controls li.sy-prev a:hover:after,
					.adt-fastslider-container-'.$instance.' .sy-controls li.sy-next a:hover:after {
						background-color:'.$adt_fastslider_color_np.'!important;
						transition: background-color 0.3s ease 0s; 	
					}
					.adt-fastslider-container-'.$instance.' .sy-pager li.sy-active a {
						border:2px solid '.$adt_fastslider_color_np.'!important;
					}
					.adt-fastslider-container-'.$instance.' .fs-preload {
						background:'.$adt_fastslider_preload_bg_color.';
					}
					.adt-fastslider-container-'.$instance.' .spinner-plane, 
					.adt-fastslider-container-'.$instance.' .spinner-wave > div, 
					.adt-fastslider-container-'.$instance.' .spinner-bounce .double-bounce1, 
					.adt-fastslider-container-'.$instance.' .spinner-bounce .double-bounce2, 
					.adt-fastslider-container-'.$instance.' .spinner-cubes .cube1, 
					.adt-fastslider-container-'.$instance.' .spinner-cubes .cube2, 
					.adt-fastslider-container-'.$instance.' .spinner-pulse,  
					.adt-fastslider-container-'.$instance.' .spinner-dots .dot1, 
					.adt-fastslider-container-'.$instance.' .spinner-dots .dot2, 
					.adt-fastslider-container-'.$instance.' .spinner-three-bounce > div,  
					.adt-fastslider-container-'.$instance.' .spinner-circle .container1 > div, 
					.adt-fastslider-container-'.$instance.' .spinner-circle .container2 > div, 
					.adt-fastslider-container-'.$instance.' .spinner-circle .container3 > div { 
						background:'.$adt_fastslider_preload_spinner_color.';
					}';
		$return .= '</style>';
		
		/******************************/
		/******* #SLYLE SLIDER ********/
		/******************************/
		
		$return .= '<div class="fastslider-container adt-fastslider-container-'.$instance.' adt-fastslider-pagination-'.$adt_fastslider_navigation_style.' adt-fastslider-navigation-'.$adt_fastslider_navigation_style.' '.$adt_fastslider_transition_class.' fs-loading-preloader">';
		
		$return .= '<ul id="adt-fastslider-'.$instance.'" class="fastslider-slides-container">';
		
		$i = 1;
		foreach($slides[0] as $slide) {		
			$slide_id = adt_fastgallery_attachment_url_to_postid( $slide['slide'] );
			
			
			
			if($slide_id == '') { /* FIX FOR IMPORT SLIDERS */
				$url = $slide['slide']; 
			} else { /* END FIX */
				$url = wp_get_attachment_image_src($slide_id,'adt_fastslider');
				$url = $url[0];
			}
			
			
			$return .= '<li><div class="adt-fastslider-pattern" style="background-color:'.$adt_fastslider_bg_color_pattern.';opacity:'.$adt_fastslider_bg_opacity_pattern.'"></div>';
			$return .= '<img src="'.$url.'">';
			
			$top_text = $top_right_text = $top_left_text = $bottom_text = $bottom_right_text = $bottom_left_text = $middle_text = $middle_right_text = $middle_left_text = '';
			
			for($count_text = 0; $count_text <= 9; $count_text++) {

				if($slide['delay_'.$count_text.''] == 'none') { $slide['delay_'.$count_text.''] = '0'; }
				
				if($slide['text_'.$count_text.''] != '') {
					
					$style_button = '';
					
					if($slide['custom_color_'.$count_text.''] == 'on') { 
						
						$color = 'color:'.$slide['color_'.$count_text.''].''; 
						
						if(	$slide['attribute_'.$count_text.''] == 'span1' ||
							$slide['attribute_'.$count_text.''] == 'span2' ||
							$slide['attribute_'.$count_text.''] == 'span3' ||
							$slide['attribute_'.$count_text.''] == 'span4' ||
							$slide['attribute_'.$count_text.''] == 'span5' ||
							$slide['attribute_'.$count_text.''] == 'span6' ||
							$slide['attribute_'.$count_text.''] == 'span7') {
								$color = 'color:'.$slide['color_'.$count_text.''].';border: 2px solid '.$slide['color_'.$count_text.''].';'; 
								$style_over_button = 'this.style.color="'.$slide['color_'.$count_text.''].'"'; 
								$return  .= '<script>jQuery(document).ready(function($){
													$("span a").mouseover(function(){
														var color = $(this).attr("data-color");
														var bg_color = $(this).attr("data-background");
														var styles = {
														  backgroundColor : color,
														  color: bg_color,
														  borderColor: bg_color 
														};		
														$(this).css(styles);
													});
													$("span a").mouseout(function(){
														var color = $(this).attr("data-color");
														var bg_color = $(this).attr("data-background");
														var styles = {
														  backgroundColor : bg_color,
														  color: color,
														  borderColor: color 
														};		
														$(this).css(styles);
													});
												});</script>';							
							}
						
					} else { 
						
						$color = ''; 
						
					}
					
					if($slide['custom_bg_color_'.$count_text.''] == 'on') { 
					
						if($slide['custom_bg_color_opacity_'.$count_text.''] == '') {
							$slide['custom_bg_color_opacity_'.$count_text.''] = '1';		
						} 
						
						$background_rgba = adt_fastslider_shex2rgb($slide['bg_color_'.$count_text.'']);

						$bg = 'background:rgba( '.$background_rgba[0].' , '.$background_rgba[1].' , '.$background_rgba[2].' , '.$slide['custom_bg_color_opacity_'.$count_text.''].');padding:16px 28px;'; 
						
					} else { 
					
						$bg = ''; 
						
					}
					
					
					
					
					$button_class = $button_active = '';
					if($slide['attribute_'.$count_text.''] == 'span1') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style1'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; }
					if($slide['attribute_'.$count_text.''] == 'span2') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style2'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; }
					if($slide['attribute_'.$count_text.''] == 'span3') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style3'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; }
					if($slide['attribute_'.$count_text.''] == 'span4') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style4'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; }
					if($slide['attribute_'.$count_text.''] == 'span5') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style5'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; 
						
						$background_rgba = adt_fastslider_shex2rgb($slide['bg_color_'.$count_text.'']);

						$slide['bg_color_'.$count_text.''] = 'rgba( '.$background_rgba[0].' , '.$background_rgba[1].' , '.$background_rgba[2].' , '.$slide['custom_bg_color_opacity_'.$count_text.''].')'; 
		
					}
					if($slide['attribute_'.$count_text.''] == 'span6') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style6'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; 
					
						$background_rgba = adt_fastslider_shex2rgb($slide['bg_color_'.$count_text.'']);

						$slide['bg_color_'.$count_text.''] = 'rgba( '.$background_rgba[0].' , '.$background_rgba[1].' , '.$background_rgba[2].' , '.$slide['custom_bg_color_opacity_'.$count_text.''].')'; 

					
					}
					if($slide['attribute_'.$count_text.''] == 'span7') { $slide['attribute_'.$count_text.''] = 'span'; $button_class = 'adt-fastslider-button-style7'; $url = $slide['url_button_'.$count_text.'']; $button_active = 'button'; }
					
					
					if($slide['display_'.$count_text.''] == 'block') {
						$block = '<div class="adt-block"></div>';	
					} else { 
						$block = ''; 
					}
					
					
					if($button_active == 'button') {
						$text = '<'.$slide['attribute_'.$count_text.''].' id="'.$button_class.'" class="adt-text-'.$count_text.' no-animation" data-delay="'.$slide['delay_'.$count_text.''].'" data-effect="'.$slide['effect_'.$count_text.''].'"><a href="'.$url.'" style="font-weight:'.$slide['font_weight_'.$count_text.''].';background-color:'.$slide['bg_color_'.$count_text.''].';color:'.$slide['color_'.$count_text.''].';border-color:'.$slide['color_'.$count_text.''].';" data-color="'.$slide['color_'.$count_text.''].'" data-background="'.$slide['bg_color_'.$count_text.''].'">'.$slide['text_'.$count_text.''].'</a></'.$slide['attribute_'.$count_text.''].'>'.$block.'';						
					} else {
						$text = '<'.$slide['attribute_'.$count_text.''].' class="adt-text-'.$count_text.' no-animation '.$button_class.'" data-delay="'.$slide['delay_'.$count_text.''].'" data-effect="'.$slide['effect_'.$count_text.''].'" style="font-weight:'.$slide['font_weight_'.$count_text.''].';'.$color.';'.$bg.'">'.$slide['text_'.$count_text.''].'</'.$slide['attribute_'.$count_text.''].'>'.$block.'';
					}
					
					
					
					if($slide['position_'.$count_text.''] == 'top') 			{ $top_text .= $text; 			}	
					if($slide['position_'.$count_text.''] == 'top-right') 		{ $top_right_text .= $text; 	}	
					if($slide['position_'.$count_text.''] == 'top-left') 		{ $top_left_text .= $text; 		}	
					if($slide['position_'.$count_text.''] == 'bottom') 			{ $bottom_text .= $text; 		}	
					if($slide['position_'.$count_text.''] == 'bottom-right') 	{ $bottom_right_text .= $text; 	}	
					if($slide['position_'.$count_text.''] == 'bottom-left') 	{ $bottom_left_text .= $text; 	}	
					if($slide['position_'.$count_text.''] == 'middle') 			{ $middle_text .= $text; 		}	
					if($slide['position_'.$count_text.''] == 'middle-right') 	{ $middle_right_text .= $text; 	}	
					if($slide['position_'.$count_text.''] == 'middle-left') 	{ $middle_left_text .= $text; 	}
					
				}
			}
			$return .= '<div class="adt-fastslider-positions">';
			
			if($top_text != '') 			{ 	$return .= '<div class="adt-fastslider-top">'.$top_text.'</div>'; 						}
			if($top_right_text != '') 		{ 	$return .= '<div class="adt-fastslider-top-right">'.$top_right_text.'</div>'; 			}
			if($top_left_text != '')		{ 	$return .= '<div class="adt-fastslider-top-left">'.$top_left_text.'</div>'; 			}
			if($middle_text != '') 			{ 	$return .= '<div class="adt-fastslider-middle">'.$middle_text.'</div>'; 				}
			if($middle_right_text != '') 	{ 	$return .= '<div class="adt-fastslider-middle-right">'.$middle_right_text.'</div>'; 	}
			if($middle_left_text != '') 	{ 	$return .= '<div class="adt-fastslider-middle-left">'.$middle_left_text.'</div>'; 		}				
			if($bottom_text != '') 			{ 	$return .= '<div class="adt-fastslider-bottom">'.$bottom_text.'</div>'; 				}
			if($bottom_right_text != '') 	{ 	$return .= '<div class="adt-fastslider-bottom-right">'.$bottom_right_text.'</div>'; 	}
			if($bottom_left_text != '') 	{ 	$return .= '<div class="adt-fastslider-bottom-left">'.$bottom_left_text.'</div>'; 		}
			
			$return .= '</div>';
			
			$return .= '</li>';
			
		$i++;
		}

		$return .= '</ul>';
		
		$return .= adt_fastslider_preload(get_post_meta( get_the_ID(), 'adt_fastslider_preload', true ));
		
		$return .= '</div>';
		
		
	
		endwhile;
		}
		wp_reset_query();
		return $return;
}
add_shortcode("adt_fastslider", "adt_fastslider");


function adt_fastslider_js($instance,$transition,$speed,$pause,$preload,$autoHover,$pagination,$navigation,$autoplay,$loop) {
	
		if($speed == '') { $speed = '2000'; }
		if($pause == '') { $pause = '4000'; }
		
		$return = '<script>';
		
		if($preload != 'off') {
				
			$return .= "jQuery(document).ready(function($){	
			
				setTimeout(function(){
					$('.fs-preload-container').removeClass('fs-preload').addClass('fs-loaded');
					$('.fs-loading-preloader').removeClass('fs-loading-preloader');
				}, 5000);
				
				setTimeout(function(){
					$(function() {
						var fastslider".$instance." = $(\"#adt-fastslider-".$instance."\").slippry({
							transition: '".$transition."',
							useCSS: true,
							speed: ".$speed.",
							pause: ".$pause.",
							autoHover: ".$autoHover.",
							pager: ".$pagination.",
							controls: ".$navigation.",					
							auto: ".$autoplay.",		
							loop: ".$loop.",
							onSlideAfter: function () {														
												
										var delayadttext0 = $('.sy-active .adt-text-0').attr(\"data-delay\");
										var effect0 = $('.sy-active .adt-text-0').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-0').removeAttr('class').addClass('adt-text-0').addClass('no-animation'); 
												$('.sy-active .adt-text-0').removeClass('no-animation').addClass('animation').addClass(effect0); }
										, delayadttext0);
										
												
										var delayadttext1 = $('.sy-active .adt-text-1').attr(\"data-delay\");
										var effect1 = $('.sy-active .adt-text-1').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-1').removeAttr('class').addClass('adt-text-1').addClass('no-animation'); 
												$('.sy-active .adt-text-1').removeClass('no-animation').addClass('animation').addClass(effect1); }
										, delayadttext1);
										
												
										var delayadttext2 = $('.sy-active .adt-text-2').attr(\"data-delay\");
										var effect2 = $('.sy-active .adt-text-2').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-2').removeAttr('class').addClass('adt-text-2').addClass('no-animation'); 
												$('.sy-active .adt-text-2').removeClass('no-animation').addClass('animation').addClass(effect2); }
										, delayadttext2);
		
												
										var delayadttext3 = $('.sy-active .adt-text-3').attr(\"data-delay\");
										var effect3 = $('.sy-active .adt-text-3').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-3').removeAttr('class').addClass('adt-text-3').addClass('no-animation'); 
												$('.sy-active .adt-text-3').removeClass('no-animation').addClass('animation').addClass(effect3); }
										, delayadttext3);	
										
												
										var delayadttext4 = $('.sy-active .adt-text-4').attr(\"data-delay\");
										var effect4 = $('.sy-active .adt-text-4').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-4').removeAttr('class').addClass('adt-text-4').addClass('no-animation'); 
												$('.sy-active .adt-text-4').removeClass('no-animation').addClass('animation').addClass(effect4); }
										, delayadttext4);								
										
												
										var delayadttext5 = $('.sy-active .adt-text-5').attr(\"data-delay\");
										var effect5 = $('.sy-active .adt-text-5').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-5').removeAttr('class').addClass('adt-text-5').addClass('no-animation'); 
												$('.sy-active .adt-text-5').removeClass('no-animation').addClass('animation').addClass(effect5); }
										, delayadttext5);								
		
												
										var delayadttext6 = $('.sy-active .adt-text-6').attr(\"data-delay\");
										var effect6 = $('.sy-active .adt-text-6').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-6').removeAttr('class').addClass('adt-text-6').addClass('no-animation'); 
												$('.sy-active .adt-text-6').removeClass('no-animation').addClass('animation').addClass(effect6); }
										, delayadttext6);
		
												
										var delayadttext7 = $('.sy-active .adt-text-7').attr(\"data-delay\");
										var effect7 = $('.sy-active .adt-text-7').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-7').removeAttr('class').addClass('adt-text-7').addClass('no-animation'); 
												$('.sy-active .adt-text-7').removeClass('no-animation').addClass('animation').addClass(effect7); }
										, delayadttext7);
		
											
										var delayadttext8 = $('.sy-active .adt-text-8').attr(\"data-delay\");
										var effect8 = $('.sy-active .adt-text-8').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-8').removeAttr('class').addClass('adt-text-8').addClass('no-animation'); 
												$('.sy-active .adt-text-8').removeClass('no-animation').addClass('animation').addClass(effect8); }
										, delayadttext8);
		
			
										var delayadttext9 = $('.sy-active .adt-text-9').attr(\"data-delay\");
										var effect9 = $('.sy-active .adt-text-9').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-9').removeAttr('class').addClass('adt-text-9').addClass('no-animation'); 
												$('.sy-active .adt-text-9').removeClass('no-animation').addClass('animation').addClass(effect9); }
										, delayadttext9);
																																	 
							}
						});
	
	
						});				
					
					}, 5000);
					
			});";
		
		} else {
			
			$return .= "jQuery(document).ready(function($){	
			
					$(function() {
						var fastslider".$instance." = $(\"#adt-fastslider-".$instance."\").slippry({
							transition: '".$transition."',
							useCSS: true,
							speed: ".$speed.",
							pause: ".$pause.",
							autoHover: ".$autoHover.",
							pager: ".$pagination.",
							controls: ".$navigation.",					
							auto: ".$autoplay.",		
							loop: ".$loop.",
							onSlideAfter: function () {														
												
										var delayadttext0 = $('.sy-active .adt-text-0').attr(\"data-delay\");
										var effect0 = $('.sy-active .adt-text-0').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-0').removeAttr('class').addClass('adt-text-0').addClass('no-animation'); 
												$('.sy-active .adt-text-0').removeClass('no-animation').addClass('animation').addClass(effect0); }
										, delayadttext0);
										
												
										var delayadttext1 = $('.sy-active .adt-text-1').attr(\"data-delay\");
										var effect1 = $('.sy-active .adt-text-1').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-1').removeAttr('class').addClass('adt-text-1').addClass('no-animation'); 
												$('.sy-active .adt-text-1').removeClass('no-animation').addClass('animation').addClass(effect1); }
										, delayadttext1);
										
												
										var delayadttext2 = $('.sy-active .adt-text-2').attr(\"data-delay\");
										var effect2 = $('.sy-active .adt-text-2').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-2').removeAttr('class').addClass('adt-text-2').addClass('no-animation'); 
												$('.sy-active .adt-text-2').removeClass('no-animation').addClass('animation').addClass(effect2); }
										, delayadttext2);
		
												
										var delayadttext3 = $('.sy-active .adt-text-3').attr(\"data-delay\");
										var effect3 = $('.sy-active .adt-text-3').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-3').removeAttr('class').addClass('adt-text-3').addClass('no-animation'); 
												$('.sy-active .adt-text-3').removeClass('no-animation').addClass('animation').addClass(effect3); }
										, delayadttext3);	
										
												
										var delayadttext4 = $('.sy-active .adt-text-4').attr(\"data-delay\");
										var effect4 = $('.sy-active .adt-text-4').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-4').removeAttr('class').addClass('adt-text-4').addClass('no-animation'); 
												$('.sy-active .adt-text-4').removeClass('no-animation').addClass('animation').addClass(effect4); }
										, delayadttext4);								
										
												
										var delayadttext5 = $('.sy-active .adt-text-5').attr(\"data-delay\");
										var effect5 = $('.sy-active .adt-text-5').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-5').removeAttr('class').addClass('adt-text-5').addClass('no-animation'); 
												$('.sy-active .adt-text-5').removeClass('no-animation').addClass('animation').addClass(effect5); }
										, delayadttext5);								
		
												
										var delayadttext6 = $('.sy-active .adt-text-6').attr(\"data-delay\");
										var effect6 = $('.sy-active .adt-text-6').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-6').removeAttr('class').addClass('adt-text-6').addClass('no-animation'); 
												$('.sy-active .adt-text-6').removeClass('no-animation').addClass('animation').addClass(effect6); }
										, delayadttext6);
		
												
										var delayadttext7 = $('.sy-active .adt-text-7').attr(\"data-delay\");
										var effect7 = $('.sy-active .adt-text-7').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-7').removeAttr('class').addClass('adt-text-7').addClass('no-animation'); 
												$('.sy-active .adt-text-7').removeClass('no-animation').addClass('animation').addClass(effect7); }
										, delayadttext7);
		
											
										var delayadttext8 = $('.sy-active .adt-text-8').attr(\"data-delay\");
										var effect8 = $('.sy-active .adt-text-8').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-8').removeAttr('class').addClass('adt-text-8').addClass('no-animation'); 
												$('.sy-active .adt-text-8').removeClass('no-animation').addClass('animation').addClass(effect8); }
										, delayadttext8);
		
			
										var delayadttext9 = $('.sy-active .adt-text-9').attr(\"data-delay\");
										var effect9 = $('.sy-active .adt-text-9').attr(\"data-effect\");
										
										setTimeout(function() { 
												$('.adt-text-9').removeAttr('class').addClass('adt-text-9').addClass('no-animation'); 
												$('.sy-active .adt-text-9').removeClass('no-animation').addClass('animation').addClass(effect9); }
										, delayadttext9);
																																	 
							}
						});
	
	
						});				
					
			});";
					
		}
		
		$return .= '</script>';
		
		return $return;	
	
}

function adt_fastslider_preload($preload) {
	
	$return = '';

	if($preload == 'spinner-plane') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-plane"></div>
				   </div>'; 
	
	}

	if($preload == 'spinner-bounce') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-bounce">
							<div class="double-bounce1"></div>
      						<div class="double-bounce2"></div>
			  	 		</div>
				   </div>'; 
	
	}
	
	if($preload == 'spinner-wave') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-wave">
				  			<div class="rect1"></div>
				  			<div class="rect2"></div>
				  			<div class="rect3"></div>
				  			<div class="rect4"></div>
				  			<div class="rect5"></div>
   		 	 			</div>
				   </div>'; 
	
	}

	if($preload == 'spinner-cubes') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-cubes">
				  			<div class="cube1"></div>
				  			<div class="cube2"></div>
   		 	 			</div>
				   </div>'; 
	
	}

	if($preload == 'spinner-pulse') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-pulse"></div>
				   </div>'; 
	
	}

	if($preload == 'spinner-dots') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-dots">
				  			<div class="dot1"></div>
				  			<div class="dot2"></div>
    		 			</div>
				   </div>'; 
	
	}

	if($preload == 'spinner-three-bounce') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-three-bounce">
				  			<div class="bounce1"></div>
				  			<div class="bounce2"></div>
				  			<div class="bounce3"></div>
    		 			</div>
				   </div>'; 
	
	}

	if($preload == 'spinner-circle') {
		
		$return = '<div class="fs-preload-container fs-preload">
						<div class="spinner-circle">
							<div class="spinner-container container1">
							  <div class="circle1"></div>
							  <div class="circle2"></div>
							  <div class="circle3"></div>
							  <div class="circle4"></div>
							</div>
							<div class="spinner-container container2">
							  <div class="circle1"></div>
							  <div class="circle2"></div>
							  <div class="circle3"></div>
							  <div class="circle4"></div>
							</div>
							<div class="spinner-container container3">
							  <div class="circle1"></div>
							  <div class="circle2"></div>
							  <div class="circle3"></div>
							  <div class="circle4"></div>
							</div>
					 </div>
				   </div>'; 
	
	}

	return $return;	
		
}

function adt_custom_code(	$instance,
							$custom_css,
							$custom_js
						) {
	$return = '';
	
	if($custom_css != '') {
		$return = '<style>'.$custom_css.'</style>';
	}
	
	if($custom_js != '') {
		$return = '<script>'.$custom_js.'</script>';	
	}
	
	return $return;
	
}
?>