<?php
/*
Description: metabox.php
Author: AD-THEME
*/

function fastslider_options_effects() {
	$options = array (
		'none'					=> 'none',
		'bounce' 				=> 'bounce',
		'flash' 				=> 'flash',
		'pulse' 				=> 'pulse',
		'rubberBand' 			=> 'rubberBand',
		'shake' 				=> 'shake',
		'headShake' 			=> 'headShake',
		'swing'					=> 'swing',
		'tada'					=> 'tada',
		'wobble'				=> 'wobble',
		'jello'					=> 'jello',
		'bounceIn'				=> 'bounceIn',
		'bounceInDown'			=> 'bounceInDown',
		'bounceInLeft'			=> 'bounceInLeft',
		'bounceInRight'			=> 'bounceInRight',
		'bounceInUp'			=> 'bounceInUp',
		'bounceOut'				=> 'bounceOut',
		'bounceOutDown'			=> 'bounceOutDown',
		'bounceOutLeft'			=> 'bounceOutLeft',
		'bounceOutRight' 		=> 'bounceOutRight',
		'bounceOutUp' 			=> 'bounceOutUp',
		'fadeIn'				=> 'fadeIn',
		'fadeInDown'			=> 'fadeInDown',
		'fadeInDownBig'			=> 'fadeInDownBig',
		'fadeInLeft'			=> 'fadeInLeft',
		'fadeInLeftBig'			=> 'fadeInLeftBig',
		'fadeInRight'			=> 'fadeInRight',
		'fadeInRightBig'		=> 'fadeInRightBig',
		'fadeInUp'				=> 'fadeInUp',
		'fadeInUpBig'			=> 'fadeInUpBig',
		'fadeOut'				=> 'fadeOut',
		'fadeOutDown'			=> 'fadeOutDown',
		'fadeOutDownBig'		=> 'fadeOutDownBig',
		'fadeOutLeft'			=> 'fadeOutLeft',
		'fadeOutLeftBig'		=> 'fadeOutLeftBig',
		'fadeOutRight'			=> 'fadeOutRight',
		'fadeOutRightBig'		=> 'fadeOutRightBig',
		'fadeOutUp'				=> 'fadeOutUp',
		'fadeOutUpBig'			=> 'fadeOutUpBig',
		'flipInX'				=> 'flipInX',
		'flipInY'				=> 'flipInY',
		'flipOutX'				=> 'flipOutX',
		'flipOutY'				=> 'flipOutY',
		'lightSpeedIn'			=> 'lightSpeedIn',
		'lightSpeedOut'			=> 'lightSpeedOut',
		'rotateIn'				=> 'rotateIn',
		'rotateInDownLeft' 		=> 'rotateInDownLeft',
		'rotateInDownRight' 	=> 'rotateInDownRight',
		'rotateInUpLeft' 		=> 'rotateInUpLeft',
		'rotateInUpRight' 		=> 'rotateInUpRight',
		'rotateOut' 			=> 'rotateOut',
		'rotateOutDownLeft' 	=> 'rotateOutDownLeft',
		'rotateOutDownRight' 	=> 'rotateOutDownRight',
		'rotateOutUpLeft' 		=> 'rotateOutUpLeft',
		'rotateOutUpRight' 		=> 'rotateOutUpRight',
		'hinge' 				=> 'hinge',
		'rollIn' 				=> 'rollIn',
		'rollOut'				=> 'rollOut',
		'zoomIn' 				=> 'zoomIn',
		'zoomInDown' 			=> 'zoomInDown',
		'zoomInLeft' 			=> 'zoomInLeft',
		'zoomInRight' 			=> 'zoomInRight',
		'zoomInUp' 				=> 'zoomInUp',
		'zoomOut'				=> 'zoomOut',
		'zoomOutDown' 			=> 'zoomOutDown',
		'zoomOutLeft' 			=> 'zoomOutLeft',
		'zoomOutRight' 			=> 'zoomOutRight',
		'zoomOutUp' 			=> 'zoomOutUp',
		'slideInDown' 			=> 'slideInDown',
		'slideInLeft' 			=> 'slideInLeft',
		'slideInRight'			=> 'slideInRight',
		'slideInUp' 			=> 'slideInUp',
		'slideOutDown'		 	=> 'slideOutDown',
		'slideOutLeft' 			=> 'slideOutLeft',
		'slideOutRight' 		=> 'slideOutRight',
		'slideOutUp' 			=> 'slideOutUp'
	);
	
	return $options;
}

function fastslider_options_positions() {
	$options = array (
		'Top' 			=> 'top',
		'Top Right' 	=> 'top-right',
		'Top Left'		=> 'top-left',
		'Bottom' 		=> 'bottom',
		'Bottom Right' 	=> 'bottom-right',
		'Bottom Left'	=> 'bottom-left',
		'Middle' 		=> 'middle',
		'Middle Right' 	=> 'middle-right',
		'Middle Left'	=> 'middle-left',				
	);
	
	return $options;
}

function fastslider_options_attribute() {
	$options = array (
		'H1' 				=> 'h1',
		'H2' 				=> 'h2',
		'H3'				=> 'h3',
		'H4' 				=> 'h4',
		'H5' 				=> 'h5',
		'H6' 				=> 'h6',
		'Button Style 1' 	=> 'span1',
		'Button Style 2' 	=> 'span2',
		'Button Style 3' 	=> 'span3',
		'Button Style 4' 	=> 'span4',
		'Button Style 5' 	=> 'span5',
		'Button Style 6' 	=> 'span6',
		'Button Style 7' 	=> 'span7',			
	);
	
	return $options;
}

function fastslider_options_font_weight() {
	$options = array (
		'normal'		=> 'normal',
		'100'			=> '100',
		'200'			=> '200',
		'300'			=> '300',
		'400'			=> '400',
		'500'			=> '500',
		'600'			=> '600',
		'700'			=> '700',
		'800'			=> '800',
		'900'			=> '900'
	);
	
	return $options;													
}

function fastslider_options_delay() {
	$options = array (
		'none' 			=> 'none',
		'100' 			=> '100',
		'200'			=> '200',
		'300' 			=> '300',
		'400' 			=> '400',
		'500' 			=> '500',
		'600' 			=> '600',
		'700'			=> '700',
		'800' 			=> '800',
		'900'			=> '900',
		'1000' 			=> '1000',
		'1500' 			=> '1500',
		'2000' 			=> '2000',
		'2500' 			=> '2500',
		'3000' 			=> '3000',
		'3500' 			=> '3500',
		'4000' 			=> '4000',
		'4500'			=> '4500',		
		'5000' 			=> '5000',
		'5500' 			=> '5500',
		'6000' 			=> '6000',
		'6500' 			=> '6500',
		'7000' 			=> '7000',
		'7500' 			=> '7500',
		'8000' 			=> '8000',
		'8500'			=> '8500',		
		'9000' 			=> '9000',
		'9500' 			=> '9500',
		'10000' 		=> '10000',
		'10500' 		=> '10500',
		'11000' 		=> '11000',
		'11500' 		=> '11500',
		'12000' 		=> '12000',
		'12500'			=> '12500',		
		'13000'			=> '13000'									
	);
	
	return $options;
}

add_action('admin_init', 'adtheme_fastslider_add_meta_boxes', 1);
function adtheme_fastslider_add_meta_boxes() {
	add_meta_box( 'slides', 
				  'Slides', 
				  'adtheme_fastslider_meta_box', 
				  'adt_fastslider', 
				  'normal', 
				  'default'
	);
}

function adtheme_fastslider_meta_box() {
	global $post;

	$repeatable_fields = get_post_meta($post->ID, 'slides', true);
	$options = fastslider_options_effects();
	$positions_options = fastslider_options_positions();
	$attribute_options = fastslider_options_attribute();
	$font_weight_options = fastslider_options_font_weight();
	$delay_options = fastslider_options_delay();

	wp_nonce_field( 'adtheme_fastslider_meta_box_nonce', 'adtheme_fastslider_meta_box_nonce' );
	?>
	<script type="text/javascript">
	jQuery(document).ready(function( $ ){
		$( "#row-slides" ).sortable();
    	//$( "#row-slides" ).disableSelection();
		
		
		$( '#add-row' ).on('click', function() {
			var row = $( '.adt-empty-row.adt-fastslider-row' ).clone(true);
			row.removeClass( 'adt-empty-row' );
			row.insertBefore( '.add-new-row' );
			return false;
		});

		$( '.copy-row' ).on('click', function() {
			var row = $(this).parent().parent().clone(true);
			row.insertBefore( '.add-new-row' );
			return false;
		});
  	
		$( '.remove-row' ).on('click', function() {
			var r = confirm("Delete slide. Are you sure?");
			if (r == true) {
				$(this).parent().parent('div').remove();
			}
			return false;
		});
				
		$("a.adt-open-slide").click(function(event) {
			event.preventDefault();
			$(this).closest(".adt-fastslider-row").find('.adt-fastslider-field-container').slideToggle(500);
		});		
		
		$("a.adt-open-text").click(function(event) {
			//event.preventDefault();
			$(this).parent().parent().find('.field-options-container').slideToggle(500);
		});	
			
		$(".field-color.field-picker select").on('change', function() {
			$(this).parent().find('.color-field').wpColorPicker();
		});
		
		
		$(function() {
			$('.color-field-saved').wpColorPicker();
		});	
		
	});	
		
	function adt_fastslider_button_check() {
		jQuery(document).ready(function( $ ){
			$(".field-attribute select").click(function(event) {
				var attribute = $(this).val();
				if(	attribute == 'span1' || 
					attribute == 'span2' || 
					attribute == 'span3' || 
					attribute == 'span4' || 
					attribute == 'span5' || 
					attribute == 'span6' ||
					attribute == 'span7' ) {
					$(this).parent().parent().parent().find('.field-url').css('display','block');
				} else {
					$(this).parent().parent().parent().find('.field-url').css('display','none');				
				}
				
			});
		});
	}	
			
		function colorpicker_init() {
			jQuery(document).ready(function( $ ){
				$(function() {
					$('.color-field').wpColorPicker();
				});
			});	
		}
		
	</script> 

	<style>
	#fastslider_options,
	#fastslider_custom_code {
		background: #16a085 none repeat scroll 0 0;
    	border: 3px solid #1a826e;
    	border-radius: 12px;
	}
	#fastslider_options h2,
	#fastslider_custom_code h2 {
		border-bottom:0;
		color:#FFF;
	}
	#fastslider_custom_code .inside h2 {
		padding-left:0;
	}
	#fastslider_custom_code textarea {
		width:100%;
	}
	#fastslider_options .toggle-indicator,
	#fastslider_custom_code .toggle-indicator {
		color:#FFF;
	}
	#fastslider_options .adt-fastslider-row {
		border:1px solid #FFF;
		
	}
	#fastslider_options .adt-fastslider-row h2 {
		font-weight:bold;
		text-transform:uppercase;
		padding:10px 0;
	}
	#fastslider_options .adt-slider-shorcodes-name {
		border-bottom:1px solid #1a826e;
		padding-bottom:20px;
		margin-bottom:20px;
	}
	#fastslider_options .adt-slider-options-speed,
	#fastslider_options .adt-slider-options-pause, 
	#fastslider_options .adt-slider-options-autoplay,
	#fastslider_options .adt-slider-options-navigation,
	#fastslider_options .adt-slider-options-pagination,
	#fastslider_options .adt-slider-options-preload,
	#fastslider_options .adt-slider-options-autoHover,
	#fastslider_options .adt-slider-options-loop,
	#fastslider_options .adt-slider-options-transition,
	#fastslider_options .adt-slider-options-custom-style,
	#fastslider_options .adt-slider-options-bg-color,
	#fastslider_options .adt-slider-options-opacity,
	#fastslider_options .adt-slider-options-pagination,
	#fastslider_options .adt-slider-options-navigation,
	#fastslider_options .adt-slider-options-color-np,
	#fastslider_options .adt-slider-options-preload-bg-color, 
	#fastslider_options .adt-slider-options-preload-spinner-color {
		float:left;
		width:33%;
	}
	.adt-line {
		clear:both;
		border-bottom:1px solid rgba(255,255,255,0.2);
		padding:10px 0;
		margin-bottom:10px;
	}
	.field-options-container .adt-line {
		border-bottom:1px solid rgba(255,255,255,0.04);
		display:block;
    	padding: 20px;
    	margin-bottom: 20px;		
	}
	.adt-line.adt-last {
		border-bottom:1px solid #1a826e;
		padding-top:30px;
		margin-bottom:20px;
	}
	#fastslider_options h1 {
		text-transform:uppercase;
		font-weight:bold;
		text-align:center;
		color:rgba(0,0,0,0.7);
		margin-bottom:40px;
	}
	#slides {
		background: #34495e none repeat scroll 0 0;
		border: 3px solid #2b3d4c;
		border-radius: 12px;
	}
	#slides h2 {
		border-bottom:0;
		color:#FFF;
	}
	#slides .toggle-indicator {
		color:#FFF;
	}
	#slides .adt-fastslider-row {
		border:1px solid rgba(0,0,0,0.2);
		background:rgba(0,0,0,0.2);
		border-radius:8px;
		padding:0;	
	}
	#slides .adt-fastslider-row h2 {
		font-weight:bold;
		text-transform:uppercase;
		padding:10px 0;
	}
	#slides input {
		border-radius:5px;
	}
	#slides .button {
	 	background: none;
		box-shadow: none;
		color: #fff;
		font-weight: bold;
		text-transform: uppercase;
		vertical-align: top;
		border:1px solid #fff;
		transition: background 0.3s ease 0s;
	}
	#slides .button:hover {
		background: rgba(255, 255, 255, 0.05) none repeat scroll 0 0;
		transition: background 0.3s ease 0s;
	}
	#slides .button.remove-row {
		border:0px;
		color:#FFF;
		background:#c0392b;
		transition: background 0.3s ease 0s;
	}
	#slides .button.remove-row:hover {
		color:#FFF;
		background:rgba(192,57,43,0.5);
		transition: background 0.3s ease 0s;
	}	
	.adt-fastslider-field-container {
		padding:0 15px;
	}
	.adt-empty-row { display:none; }
	.adt-hidden { display:none; }
	.adt-clear { clear:both; }
	.adt-fastslider-row {
		border:1px solid #CCC;
		padding:15px 25px 25px 25px;
		margin-bottom:50px;
	}
	.adt-fastslider-field-container {
		padding-top:25px;		
	}
	.adt-slide-info {
		border-bottom: 1px solid rgba(0, 0, 0, 0.2);
		padding: 25px;
		cursor:move;
	}
	.adt-slide-info h1 {
		width:45%;
		display:inline-block;
		padding:0;
	}
	.adt-slide-info a {
		display:inline-block;
	}
	.adt-slide-info .adt-open-slide {
		margin-right:2.5%;	
	}
	.adt-slide-info .copy-row {
		margin-right:2.5%;
	}
	.adt-fastslider-field-slide {
		border-bottom: 1px solid rgba(255, 255, 255, 0.2);
		margin-bottom: 25px;
	}	
	.adt-fastslider-field-slide input {
		width:45%;
		float:left
	}
	.adt-fastslider-field-slide .meta-image {
		margin-right:3%;
	}
	.adt-fastslider-field-slide .wrap-image {
		clear: both;
		padding: 20px 0 25px;
	}
	.adt-slide-image {
		background-size:cover;
		background-position:center;
		height:300px;	
	}
	.wrap-image img {
		max-width:100%;
		max-height:300px;
	}
	.adt-fastslider-field-options-container {
		background: rgba(0, 0, 0, 0.2) none repeat scroll 0 0;
		margin: 20px 0;
		padding: 25px;
		border-radius:12px;		
	}
	.adt-fastslider-field-options .field-options-container > div {
		display:inline-block;
		float:left;
		width:33%;
	}
	.adt-fastslider-field-options .field-options-container .field-color {
		width:100%;
	}
	.adt-fastslider-field-options .field-options-container .field-color > div {
		width:32%;
		display:inline-block;
		vertical-align:top;
	}
	.field-options-container {
		clear:both;
	}
	.field-options-container h2 {
		display:block;
	}
	.field-options-container .field-effect,
	.field-options-container .field-position,
	.field-options-container .field-attribute,
	.field-options-container .field-delay {
		width:25%;
	}
	.field-options-container .field-color {
		width:100%;	
	}
	.adt-fastslider-field-options input,
	.adt-fastslider-field-options select
	 {
		display:inline-block;
		vertical-align:top;
	}
	.adt-fastslider-field-options .field-text {
		width:100%;
	}
	.adt-fastslider-field-options .field-text h1 {
		width:100%;
		display:block;
		padding:0!important;
		color:#FFF;
		text-align:center;
		text-transform:uppercase;
		margin-bottom:40px;
		font-weight:bold;
	}
	.adt-fastslider-field-options .field-url h2 {
		width:100%;
		display:block;
		padding:25px 0 10px 0!important;		
	}
	.adt-fastslider-field-options .field-text input {
		width:100%;
		display:block;
		margin-bottom:20px;
	}
	.adt-fastslider-field-options .field-url input {
		width:100%;
		display:block;
		margin-bottom:20px;
	}
	.field-options-container h1 {
		text-transform:uppercase;
		font-weight:bold;
		color:rgba(0,0,0,0.7);
		margin-top:40px;
		border-top: 1px solid rgba(0,0,0,0.2);
		padding-top: 30px;
		margin-bottom: 20px;
		font-size:20px;
	}		
	.adt-fastslider-field-options .field-effect h2 {
		padding-left:0!important;
	}
	.post-type-adt_fastslider .wp-color-result {
		height:28px;
		box-shadow:none;
		margin:0;
	}
	.post-type-adt_fastslider .wp-color-result::after {
		height:28px;
		line-height:28px;
	}
	.post-type-adt_fastslider #submitdiv {
    	background: #34495e;
    	border: 3px solid #2b3d4c;
    	border-radius: 12px;
		text-align:center;
	}
	.post-type-adt_fastslider #submitdiv h2 {
		border-bottom:0;
		color:#FFF;
	}
	.post-type-adt_fastslider #submitdiv .toggle-indicator {
		color:#FFF;
	}
	.post-type-adt_fastslider #submitdiv #major-publishing-actions {
		background:rgba(0,0,0,0.2);
		border-top:0;
	}
	.post-type-adt_fastslider #submitdiv #publishing-action {
		display:block;
		float:none;
	}
	.post-type-adt_fastslider #submitdiv #delete-action {
		display:block;
		float:none;
	}
	.post-type-adt_fastslider #submitdiv .button {
		border:0px;
		color:#FFF;
		background:#1a826e;
		text-shadow:none;
		box-shadow:none;
	}
	.post-type-adt_fastslider #submitdiv .submitdelete {
		color:#c0392b;
		text-decoration:none;
		display:block;	
		text-align:center;
	}
	.post-type-adt_fastslider #minor-publishing {
		display:none;
	}
	.post-type-adt_fastslider #publishing-action {
		text-align:center;
		margin-top:50px;
	}
	.post-type-adt_fastslider #publishing-action .spinner {
		display:none;
	}
	</style>
	<div id="row-slides">
	<?php
	if ( $repeatable_fields ) :
	$num_slide = 1;
	foreach ( $repeatable_fields as $field ) {
		
		if($field['slide'] == '') {
			$label_image_upload = __( 'Choose or Upload an Image', 'fastslider' );
		} else {
			$label_image_upload = __( 'Change your Image', 'fastslider' );
		}
	?>
    
    <div class="adt-fastslider-row">
    
    	<div class="adt-slide-info">
        	<h1>
				<?php 
				if($field['name'] == '') {
					$field['name'] = __('Slide #','fastslider') . $num_slide; 
				}
				?>                         
				<input type="text" name="name[]" value="<?php if ( isset ( $field['name'] ) ) echo $field['name']; ?>" />        
            </h1>
        	<a class="button adt-open-slide" href="#"><?php echo __('Open/Close slide','fastslider'); ?></a>
            <a class="button copy-row" href="#"><?php echo __('Copy slide','fastslider'); ?></a>
            <a class="button remove-row" href="#"><?php echo __('Remove slide','fastslider'); ?></a>
        </div>
        
        <div class="adt-fastslider-field-container adt-hidden">
        
            <div class="adt-fastslider-field-slide">
                 <div class="field_row">
                     <div class="field_left">
                          <div class="form_field">
                            <input type="text" name="slide[]" id="meta-image" class="meta-image" value="<?php if ( isset ( $field['slide'] ) ) echo $field['slide']; ?>" readonly />
                            <input type="button" id="meta-image-button" class="button" onclick="add_slide(this)" value="<?php echo $label_image_upload; ?>" />
                            <div class="wrap-image"><div class="adt-slide-image" style="background-image:url('<?php esc_html_e( $field['slide'] ); ?>')"></div>
                          </div>
                      </div>
                  </div>
                </div>    
            </div><!-- #adt-fastslider-field-slide -->
        
        
            <div class="adt-fastslider-field-options">
                <?php $text_count = 1; for($i = 0; $i <= 9; $i++) { ?>
                
                <div class="adt-fastslider-field-options-container">
                
                	<div class="field-text-container">
                    
                        <div class="field-text">
                            <h1><?php echo __('Text','fastslider'); ?> <?php echo $text_count; ?> </h1>    
                            <h2><?php echo __('Text','fastslider'); ?></h2>
                            <input type="text" class="widefat" name="text_<?php echo $i; ?>[]" value="<?php if($field['text_'.$i.''] != '') echo esc_attr( $field['text_'.$i.''] ); ?>" />
                        </div>

						<?php 
								if(	$field['attribute_'.$i.''] == 'span1' ||
									$field['attribute_'.$i.''] == 'span2' ||
									$field['attribute_'.$i.''] == 'span3' ||
									$field['attribute_'.$i.''] == 'span4' ||
									$field['attribute_'.$i.''] == 'span5' ||
									$field['attribute_'.$i.''] == 'span6' ) {
										$url_style = 'style="display:block;"';
									} else {
										$url_style = 'style="display:none;"'; 
									}
						?>
                        <div class="field-url" <?php echo $url_style; ?>>
                            <h2><?php echo __('Button URL','fastslider'); ?> <?php echo $text_count; ?></h2>        	
                            <input type="text" class="widefat" name="url_button_<?php echo $i; ?>[]" value="<?php if($field['url_button_'.$i.''] != '') echo esc_attr( $field['url_button_'.$i.''] ); ?>" />
                        </div>
                        
                        <a class="button adt-open-text"><?php echo __('Advanced Text Options','fastslider'); ?></a>
                
                	</div>
                
                	<div class="field-options-container" style="display:none">
                
                		<h1><?php echo __('Text Options','fastslider'); ?></h1>
                
                        <div class="field-effect">
                            <h2><?php echo __('Effect','fastslider'); ?></h2>
                            <select name="effect_<?php echo $i; ?>[]">
                            <?php foreach ( $options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"<?php selected( $field['effect_'.$i.''], $value ); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>
                    
                        <div class="field-position">
                            <h2><?php echo __('Postion','fastslider'); ?></h2>
                            <select name="position_<?php echo $i; ?>[]">
                            <?php foreach ( $positions_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"<?php selected( $field['position_'.$i.''], $value ); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>                	
    
                        <div class="field-attribute">
                            <h2><?php echo __('Attribute','fastslider'); ?></h2>
                            <select name="attribute_<?php echo $i; ?>[]" onclick="adt_fastslider_button_check()">
                            <?php foreach ( $attribute_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"<?php selected( $field['attribute_'.$i.''], $value ); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>                 

						<span class="adt-line"></span>

                        <div class="field-font-weight">
                            <h2><?php echo __('Font Weight','fastslider'); ?></h2>
                            <select name="font_weight_<?php echo $i; ?>[]">
                            <?php foreach ( $font_weight_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"<?php selected( $field['font_weight_'.$i.''], $value ); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 
                        
                        <div class="field-display">
                            <h2><?php echo __('Display','fastslider'); ?></h2>
                            <select name="display_<?php echo $i; ?>[]">
                            	<option value="block" <?php selected( $field['display_'.$i.''], 'block' ); ?>><?php echo __('Block (Next text on new line)','fastgallery'); ?></option>
                            	<option value="inline" <?php selected( $field['display_'.$i.''], 'inline' ); ?>><?php echo __('Inline (Next text inline)','fastgallery'); ?></option>   
                            </select>        
                        </div>
                        
                        <div class="field-delay">
                            <h2><?php echo __('Delay (ms)','fastslider'); ?></h2>
                            <select name="delay_<?php echo $i; ?>[]">
                            <?php foreach ( $delay_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"<?php selected( $field['delay_'.$i.''], $value ); ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>                          		
                
                		<span class="adt-clear"></span>
                
                		<div class="field-color field-picker">
                        
                        	<h1><?php echo __('Text Style','fastslider'); ?></h1>
                            
                            <div class="field-custom-color">
                            
                                <h2><?php echo __('Custom Color','fastslider'); ?></h2>
                                <select name="custom_color_<?php echo $i; ?>[]">
                                    <option value="off" <?php selected( $field['custom_color_'.$i.''], 'off' ); ?>><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on" <?php selected( $field['custom_color_'.$i.''], 'on' ); ?>><?php echo __('on','fastgallery'); ?></option>                            
                                </select>
                                <?php if($field['custom_color_'.$i.''] == 'on') { ?>
                                    <input class="color-field-saved" type="text" name="color_<?php echo $i; ?>[]" value="<?php echo $field['color_'.$i.'']; ?>"/>                
                                <?php } else { ?>
                                    <input class="color-field" type="text" name="color_<?php echo $i; ?>[]" value="<?php echo $field['color_'.$i.'']; ?>"/>
                                <?php } ?>

							</div>
                            
                            <div class="field-custom-background-color">
                                                     
                                <h2><?php echo __('Custom Background Color','fastslider'); ?></h2>
                                <select name="custom_bg_color_<?php echo $i; ?>[]">
                                    <option value="off" <?php selected( $field['custom_bg_color_'.$i.''], 'off' ); ?>><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on" <?php selected( $field['custom_bg_color_'.$i.''], 'on' ); ?>><?php echo __('on','fastgallery'); ?></option>                            
                                </select>
                                <?php if($field['custom_bg_color_'.$i.''] == 'on') { ?>
                                    <input class="color-field-saved" type="text" name="bg_color_<?php echo $i; ?>[]" value="<?php echo $field['bg_color_'.$i.'']; ?>"/>
                                <?php } else { ?>
                                    <input class="color-field" type="text" name="bg_color_<?php echo $i; ?>[]" value="<?php echo $field['bg_color_'.$i.'']; ?>"/>							
                                <?php } ?>

							</div>
                            
                            <div class="field-custom-background-opacity">
							
                                <h2><?php echo __('Opacity Background (value 0.1 to 1)','fastslider'); ?></h2>     	
                                <input type="text" class="text" name="custom_bg_color_opacity_<?php echo $i; ?>[]"  value="<?php if($field['custom_bg_color_opacity_'.$i.''] != '') echo esc_attr( $field['custom_bg_color_opacity_'.$i.''] ); ?>" />

							</div>
                        
                        </div>
                
                	</div>
                    
                    	

                	<div class="adt-clear"></div>
                
                </div>
                
                <?php $text_count++; } ?> 
            </div><!-- #adt-fastslider-field-options -->
    
    	</div><!-- #adt-fastslider-field-container -->	
        
        <div class="adt-clear"></div>
        
    </div>
	
	<?php
	$num_slide++;
	}
	else :


	?>

    <!-- JQUERY EMPTY ROW -->
    <div class="adt-fastslider-row">
    
    	<div class="adt-slide-info">
        	<h1>                       
				<input type="text" name="name[]" placeholder="<?php echo __('Label Slide','fastslider'); ?>" />        
            </h1>
        	<a class="button adt-open-slide" href="#"><?php echo __('Open/Close slide','fastslider'); ?></a>
            <a class="button copy-row" href="#"><?php echo __('Copy slide','fastslider'); ?></a>
            <a class="button remove-row" href="#"><?php echo __('Remove slide','fastslider'); ?></a>
        </div> 
 
 		<div class="adt-fastslider-field-container adt-hidden">
    
            <div class="adt-fastslider-field-slide">
                 <div class="field_row">
                     <div class="field_left">
                          <div class="form_field">
                            <input type="text" name="slide[]" id="meta-image" class="meta-image" readonly />
                            <input type="button" id="meta-image-button" class="button" onclick="add_slide(this)" value="<?php echo __( 'Choose or Upload an Image', 'fastslider' ); ?>" />
                            <div class="wrap-image"></div>
                      </div>
                  </div>
                </div>    
            </div><!-- #adt-fastslider-field-slide -->
        
        
            <div class="adt-fastslider-field-options">
                <?php $text_count = 1; for($i = 0; $i <= 9; $i++) { ?>
                
                <div class="adt-fastslider-field-options-container">
                
                	<div class="field-text-container">
                
                        <div class="field-text">
                            <h1><?php echo __('Text','fastslider'); ?> <?php echo $text_count; ?></h1>    
                            <h2><?php echo __('Text','fastslider'); ?></h2>    	
                            <input type="text" class="widefat" name="text_<?php echo $i; ?>[]" />                            
                        </div>
                        
                        <div class="field-url" style="display:none">
                            <h2><?php echo __('Button URL','fastslider'); ?> <?php echo $text_count; ?></h2>        	
                            <input type="text" class="widefat" name="url_button_<?php echo $i; ?>[]" />
                        </div> 
                        
                        <a class="button adt-open-text"><?php echo __('Advanced Text Options','fastslider'); ?></a>           
                	
                    </div>
                
                	<div class="field-options-container" style="display:none;">
                
                		<h1><?php echo __('Text Options','fastslider'); ?></h1>
                
                        <div class="field-effect">
                            <h2><?php echo __('Effect Text','fastslider'); ?></h2>
                            <select name="effect_<?php echo $i; ?>[]">
                            <?php foreach ( $options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>

                        <div class="field-position">
                            <h2><?php echo __('Postion','fastslider'); ?></h2>
                            <select name="position_<?php echo $i; ?>[]">
                            <?php foreach ( $positions_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 

                        <div class="field-attribute">
                            <h2><?php echo __('Attribute','fastslider'); ?></h2>
                            <select name="attribute_<?php echo $i; ?>[]" onclick="adt_fastslider_button_check()">
                            <?php foreach ( $attribute_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 

						<span class="adt-line"></span>

                        <div class="field-font-weight">
                            <h2><?php echo __('Font Weight','fastslider'); ?></h2>
                            <select name="font_weight_<?php echo $i; ?>[]">
                            <?php foreach ( $font_weight_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 

                        <div class="field-display">
                            <h2><?php echo __('Display','fastslider'); ?></h2>
                            <select name="display_<?php echo $i; ?>[]">
                            	<option value="block"><?php echo __('Block (Next text on new line)','fastgallery'); ?></option>
                            	<option value="inline"><?php echo __('Inline (Next text inline)','fastgallery'); ?></option>   
                            </select>        
                        </div>

                        <div class="field-delay">
                            <h2><?php echo __('Delay (ms)','fastslider'); ?></h2>
                            <select name="delay_<?php echo $i; ?>[]">
                            <?php foreach ( $delay_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>
            
            			<span class="adt-clear"></span>
            
                		<div class="field-color field-picker">      
 
                        	<h1><?php echo __('Text Style','fastslider'); ?></h1>
                            
                            <div class="field-custom-color"> 
                                          
                                <h2><?php echo __('Custom Color','fastslider'); ?></h2>
                                <select name="custom_color_<?php echo $i; ?>[]">
                                    <option value="off"><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on"><?php echo __('on','fastgallery'); ?></option>                            
                                </select>                       
                                <input class="color-field" type="text" name="color_<?php echo $i; ?>[]" />
                             
                            </div> 
                            
                            <div class="field-custom-background-color">
                                                       
                                <h2><?php echo __('Custom Background Color','fastslider'); ?></h2>
                                <select name="custom_bg_color_<?php echo $i; ?>[]">
                                    <option value="off"><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on"><?php echo __('on','fastgallery'); ?></option>                            
                                </select>                              
                                <input class="color-field" type="text" name="bg_color_<?php echo $i; ?>[]" />  
							
                            </div>
                            
                            <div class="field-custom-background-opacity">
                            
                                <h2><?php echo __('Opacity Background (value 0.1 to 1)','fastslider'); ?></h2>     	
                                <input type="text" class="text" name="custom_bg_color_opacity_<?php echo $i; ?>[]" />
                            
                            </div> 
                                                                         
                		</div>
                
                	</div>
                               
                	<div class="adt-clear"></div>
                
                </div>
                        
            	<?php $text_count++; } ?> 
        	</div><!-- #adt-fastslider-field-options -->
        
        </div>
        
        <div class="adt-clear"></div>
        
    </div>
	
	<?php 
	endif; 
	?>
    
    
    <!-- JQUERY EMPTY ROW -->
    <div class="adt-empty-row adt-fastslider-row">
    
    	<div class="adt-slide-info">
        	<h1>                       
				<input type="text" name="name[]" placeholder="<?php echo __('Label Slide','fastslider'); ?>" />        
            </h1>
        	<a class="button adt-open-slide" href="#"><?php echo __('Open/Close slide','fastslider'); ?></a>
            <a class="button copy-row" href="#"><?php echo __('Copy slide','fastslider'); ?></a>
            <a class="button remove-row" href="#"><?php echo __('Remove slide','fastslider'); ?></a>
        </div> 
 
    	<div class="adt-fastslider-field-container">
    
            <div class="adt-fastslider-field-slide">
                 <div class="field_row">
                     <div class="field_left">
                          <div class="form_field">
                            <input type="text" name="slide[]" id="meta-image" class="meta-image" readonly />
                            <input type="button" id="meta-image-button" class="button" onclick="add_slide(this)" value="<?php echo __( 'Choose or Upload an Image', 'fastslider' ); ?>" />
                            <div class="wrap-image"></div>
                      </div>
                  </div>
                </div>    
            </div><!-- #adt-fastslider-field-slide -->
            
            
            <div class="adt-fastslider-field-options">
                <?php 
				$text_count = 1;
				for($i = 0; $i <= 9; $i++) { ?>
                
                 <div class="adt-fastslider-field-options-container">
                
                	<div class="field-text-container">
                                   
                        <div class="field-text">
                            <h1><?php echo __('Text','fastslider'); ?> <?php echo $text_count; ?></h1>    
                            <h2><?php echo __('Text','fastslider'); ?></h2>    	
                            <input type="text" class="widefat" name="text_<?php echo $i; ?>[]" />
                            
                        </div>

                        <div class="field-url" style="display:none">
                            <h2><?php echo __('Button URL','fastslider'); ?></h2>        	
                            <input type="text" class="widefat" name="url_button_<?php echo $i; ?>[]" />
                        </div> 
                		
                        <a class="button adt-open-text"><?php echo __('Advanced Text Options','fastslider'); ?></a>
                	
                    </div>
                    
                    <div class="field-options-container" style="display:none;">
                
                		<h1><?php echo __('Text Options','fastslider'); ?></h1>
                
                        <div class="field-effect">
                            <h2><?php echo __('Effect Text','fastslider'); ?></h2>
                            <select name="effect_<?php echo $i; ?>[]">
                            <?php foreach ( $options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>

                        <div class="field-position">
                            <h2><?php echo __('Postion','fastslider'); ?></h2>
                            <select name="position_<?php echo $i; ?>[]">
                            <?php foreach ( $positions_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 

                        <div class="field-attribute">
                            <h2><?php echo __('Attribute','fastslider'); ?></h2>
                            <select name="attribute_<?php echo $i; ?>[]" onclick="adt_fastslider_button_check()">
                            <?php foreach ( $attribute_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 

						<span class="adt-line"></span>

                        <div class="field-font-weight">
                            <h2><?php echo __('Font Weight','fastslider'); ?></h2>
                            <select name="font_weight_<?php echo $i; ?>[]">
                            <?php foreach ( $font_weight_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div> 
                        
                        <div class="field-display">
                            <h2><?php echo __('Display','fastslider'); ?></h2>
                            <select name="display_<?php echo $i; ?>[]">
                            	<option value="block"><?php echo __('Block (Next text on new line)','fastgallery'); ?></option>
                            	<option value="inline"><?php echo __('Inline (Next text inline)','fastgallery'); ?></option>   
                            </select>        
                        </div>
                        
                        <div class="field-delay">
                            <h2><?php echo __('Delay (ms)','fastslider'); ?></h2>
                            <select name="delay_<?php echo $i; ?>[]">
                            <?php foreach ( $delay_options as $label => $value ) : ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                            </select>        
                        </div>
                
                		<span class="adt-clear"></span>
                
                		<div class="field-color field-picker">
                        
                        	<h1><?php echo __('Text Style','fastslider'); ?></h1>
                            
                            <div class="field-custom-color">                        
                        
                                <h2><?php echo __('Custom Color','fastslider'); ?></h2>
                                <select name="custom_color_<?php echo $i; ?>[]">
                                    <option value="off"><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on"><?php echo __('on','fastgallery'); ?></option>                            
                                </select>                        
                                <input class="color-field" type="text" name="color_<?php echo $i; ?>[]" />
                            
                            </div>
                            
                            <div class="field-custom-background-color">
                                
                                <h2><?php echo __('Custom Background Color','fastslider'); ?></h2>
                                <select name="custom_bg_color_<?php echo $i; ?>[]">
                                    <option value="off"><?php echo __('off','fastgallery'); ?></option>
                                    <option value="on"><?php echo __('on','fastgallery'); ?></option>                            
                                </select>                              
                                <input class="color-field" type="text" name="bg_color_<?php echo $i; ?>[]" /> 
                             
                            </div>   
                            
                            <div class="field-custom-background-opacity">
                                
                                <h2><?php echo __('Opacity Background (value 0.1 to 1)','fastslider'); ?></h2>     	
                                <input type="text" class="text" name="custom_bg_color_opacity_<?php echo $i; ?>[]" />
                            
                            </div>
                                                                    
                		</div>
                
                	</div>               	

                	<div class="adt-clear"></div>
                
                </div>
                
                <?php $text_count++; } ?> 
            </div><!-- #adt-fastslider-field-options -->
        
        </div>
        
        <div class="adt-clear"></div>
        
    </div>
    
    <div class="add-new-row"></div>
    
    </div>
    

	
	<p><a id="add-row" class="button" href="#"><?php echo __('Add another slide','fastslider'); ?></a></p>
    
	<?php
}

add_action('save_post', 'adtheme_fastslider_meta_box_save');
function adtheme_fastslider_meta_box_save($post_id) {
	if ( ! isset( $_POST['adtheme_fastslider_meta_box_nonce'] ) ||
	! wp_verify_nonce( $_POST['adtheme_fastslider_meta_box_nonce'], 'adtheme_fastslider_meta_box_nonce' ) )
		return;
	
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;
	
	if (!current_user_can('edit_post', $post_id))
		return;
	
	$old = get_post_meta($post_id, 'slides', true);
	$new = array();
	$options = fastslider_options_effects();
	$positions_options = fastslider_options_positions();
	$attribute_options = fastslider_options_attribute();
	$font_weight_options = fastslider_options_font_weight();
	$delay_options = fastslider_options_delay();
	
	$name = $_POST['name'];
	
	$slides = $_POST['slide'];
	
	$text_0 = $_POST['text_0'];
	$text_1 = $_POST['text_1'];
	$text_2 = $_POST['text_2'];
	$text_3 = $_POST['text_3'];
	$text_4 = $_POST['text_4'];
	$text_5 = $_POST['text_5'];
	$text_6 = $_POST['text_6'];
	$text_7 = $_POST['text_7'];
	$text_8 = $_POST['text_8'];
	$text_9 = $_POST['text_9'];

	$url_button_0 = $_POST['url_button_0'];
	$url_button_1 = $_POST['url_button_1'];
	$url_button_2 = $_POST['url_button_2'];
	$url_button_3 = $_POST['url_button_3'];
	$url_button_4 = $_POST['url_button_4'];
	$url_button_5 = $_POST['url_button_5'];
	$url_button_6 = $_POST['url_button_6'];
	$url_button_7 = $_POST['url_button_7'];
	$url_button_8 = $_POST['url_button_8'];
	$url_button_9 = $_POST['url_button_9'];

	$effects_0 = $_POST['effect_0'];
	$effects_1 = $_POST['effect_1'];
	$effects_2 = $_POST['effect_2'];
	$effects_3 = $_POST['effect_3'];
	$effects_4 = $_POST['effect_4'];
	$effects_5 = $_POST['effect_5'];
	$effects_6 = $_POST['effect_6'];
	$effects_7 = $_POST['effect_7'];
	$effects_8 = $_POST['effect_8'];
	$effects_9 = $_POST['effect_9'];
	
	$position_0 = $_POST['position_0'];
	$position_1 = $_POST['position_1'];
	$position_2 = $_POST['position_2'];
	$position_3 = $_POST['position_3'];
	$position_4 = $_POST['position_4'];
	$position_5 = $_POST['position_5'];
	$position_6 = $_POST['position_6'];
	$position_7 = $_POST['position_7'];
	$position_8 = $_POST['position_8'];
	$position_9 = $_POST['position_9'];	

	$attribute_0 = $_POST['attribute_0'];
	$attribute_1 = $_POST['attribute_1'];
	$attribute_2 = $_POST['attribute_2'];
	$attribute_3 = $_POST['attribute_3'];
	$attribute_4 = $_POST['attribute_4'];
	$attribute_5 = $_POST['attribute_5'];
	$attribute_6 = $_POST['attribute_6'];
	$attribute_7 = $_POST['attribute_7'];
	$attribute_8 = $_POST['attribute_8'];
	$attribute_9 = $_POST['attribute_9'];	

	$display_0 = $_POST['display_0'];
	$display_1 = $_POST['display_1'];
	$display_2 = $_POST['display_2'];
	$display_3 = $_POST['display_3'];
	$display_4 = $_POST['display_4'];
	$display_5 = $_POST['display_5'];
	$display_6 = $_POST['display_6'];
	$display_7 = $_POST['display_7'];
	$display_8 = $_POST['display_8'];
	$display_9 = $_POST['display_9'];

	$font_weight_0 = $_POST['font_weight_0'];
	$font_weight_1 = $_POST['font_weight_1'];
	$font_weight_2 = $_POST['font_weight_2'];
	$font_weight_3 = $_POST['font_weight_3'];
	$font_weight_4 = $_POST['font_weight_4'];
	$font_weight_5 = $_POST['font_weight_5'];
	$font_weight_6 = $_POST['font_weight_6'];
	$font_weight_7 = $_POST['font_weight_7'];
	$font_weight_8 = $_POST['font_weight_8'];
	$font_weight_9 = $_POST['font_weight_9'];

	$delay_0 = $_POST['delay_0'];
	$delay_1 = $_POST['delay_1'];
	$delay_2 = $_POST['delay_2'];
	$delay_3 = $_POST['delay_3'];
	$delay_4 = $_POST['delay_4'];
	$delay_5 = $_POST['delay_5'];
	$delay_6 = $_POST['delay_6'];
	$delay_7 = $_POST['delay_7'];
	$delay_8 = $_POST['delay_8'];
	$delay_9 = $_POST['delay_9'];
	
	$custom_color_0 = $_POST['custom_color_0'];
	$custom_color_1 = $_POST['custom_color_1'];
	$custom_color_2 = $_POST['custom_color_2'];
	$custom_color_3 = $_POST['custom_color_3'];
	$custom_color_4 = $_POST['custom_color_4'];
	$custom_color_5 = $_POST['custom_color_5'];
	$custom_color_6 = $_POST['custom_color_6'];
	$custom_color_7 = $_POST['custom_color_7'];
	$custom_color_8 = $_POST['custom_color_8'];
	$custom_color_9 = $_POST['custom_color_9'];

	$custom_bg_color_0 = $_POST['custom_bg_color_0'];
	$custom_bg_color_1 = $_POST['custom_bg_color_1'];
	$custom_bg_color_2 = $_POST['custom_bg_color_2'];
	$custom_bg_color_3 = $_POST['custom_bg_color_3'];
	$custom_bg_color_4 = $_POST['custom_bg_color_4'];
	$custom_bg_color_5 = $_POST['custom_bg_color_5'];
	$custom_bg_color_6 = $_POST['custom_bg_color_6'];
	$custom_bg_color_7 = $_POST['custom_bg_color_7'];
	$custom_bg_color_8 = $_POST['custom_bg_color_8'];
	$custom_bg_color_9 = $_POST['custom_bg_color_9'];	
	
	$color_0 = $_POST['color_0'];
	$color_1 = $_POST['color_1'];
	$color_2 = $_POST['color_2'];
	$color_3 = $_POST['color_3'];
	$color_4 = $_POST['color_4'];
	$color_5 = $_POST['color_5'];
	$color_6 = $_POST['color_6'];
	$color_7 = $_POST['color_7'];
	$color_8 = $_POST['color_8'];
	$color_9 = $_POST['color_9'];


	$bg_color_0 = $_POST['bg_color_0'];
	$bg_color_1 = $_POST['bg_color_1'];
	$bg_color_2 = $_POST['bg_color_2'];
	$bg_color_3 = $_POST['bg_color_3'];
	$bg_color_4 = $_POST['bg_color_4'];
	$bg_color_5 = $_POST['bg_color_5'];
	$bg_color_6 = $_POST['bg_color_6'];
	$bg_color_7 = $_POST['bg_color_7'];
	$bg_color_8 = $_POST['bg_color_8'];
	$bg_color_9 = $_POST['bg_color_9'];

	$custom_bg_color_opacity_0 = $_POST['custom_bg_color_opacity_0'];
	$custom_bg_color_opacity_1 = $_POST['custom_bg_color_opacity_1'];
	$custom_bg_color_opacity_2 = $_POST['custom_bg_color_opacity_2'];
	$custom_bg_color_opacity_3 = $_POST['custom_bg_color_opacity_3'];
	$custom_bg_color_opacity_4 = $_POST['custom_bg_color_opacity_4'];
	$custom_bg_color_opacity_5 = $_POST['custom_bg_color_opacity_5'];
	$custom_bg_color_opacity_6 = $_POST['custom_bg_color_opacity_6'];
	$custom_bg_color_opacity_7 = $_POST['custom_bg_color_opacity_7'];
	$custom_bg_color_opacity_8 = $_POST['custom_bg_color_opacity_8'];
	$custom_bg_color_opacity_9 = $_POST['custom_bg_color_opacity_9'];
	
	$count = count( $slides );
	
	for ( $i = 0; $i < $count; $i++ ) {
		if ( $slides[$i] != '' ) :
		
			$new[$i]['name'] = stripslashes( strip_tags( $name[$i] ) );
		
			$new[$i]['text_0'] = stripslashes( $text_0[$i] );
			$new[$i]['text_1'] = stripslashes( $text_1[$i] );
			$new[$i]['text_2'] = stripslashes( $text_2[$i] );
			$new[$i]['text_3'] = stripslashes( $text_3[$i] );
			$new[$i]['text_4'] = stripslashes( $text_4[$i] );
			$new[$i]['text_5'] = stripslashes( $text_5[$i] );
			$new[$i]['text_6'] = stripslashes( $text_6[$i] );
			$new[$i]['text_7'] = stripslashes( $text_7[$i] );
			$new[$i]['text_8'] = stripslashes( $text_8[$i] );
			$new[$i]['text_9'] = stripslashes( $text_9[$i] );
	
			$new[$i]['url_button_0'] = stripslashes( strip_tags( $url_button_0[$i] ) );
			$new[$i]['url_button_1'] = stripslashes( strip_tags( $url_button_1[$i] ) );
			$new[$i]['url_button_2'] = stripslashes( strip_tags( $url_button_2[$i] ) );
			$new[$i]['url_button_3'] = stripslashes( strip_tags( $url_button_3[$i] ) );
			$new[$i]['url_button_4'] = stripslashes( strip_tags( $url_button_4[$i] ) );
			$new[$i]['url_button_5'] = stripslashes( strip_tags( $url_button_5[$i] ) );
			$new[$i]['url_button_6'] = stripslashes( strip_tags( $url_button_6[$i] ) );
			$new[$i]['url_button_7'] = stripslashes( strip_tags( $url_button_7[$i] ) );
			$new[$i]['url_button_8'] = stripslashes( strip_tags( $url_button_8[$i] ) );
			$new[$i]['url_button_9'] = stripslashes( strip_tags( $url_button_9[$i] ) );	
	
			$new[$i]['slide'] = stripslashes( strip_tags( $slides[$i] ) );
								
			if ( in_array( $effects_0[$i], $options ) )
				$new[$i]['effect_0'] = $effects_0[$i];
			else
				$new[$i]['effect_0'] = '';
				
			if ( in_array( $effects_1[$i], $options ) )
				$new[$i]['effect_1'] = $effects_1[$i];
			else
				$new[$i]['effect_1'] = '';
				
			if ( in_array( $effects_2[$i], $options ) )
				$new[$i]['effect_2'] = $effects_2[$i];
			else
				$new[$i]['effect_2'] = '';	
				
			if ( in_array( $effects_3[$i], $options ) )
				$new[$i]['effect_3'] = $effects_3[$i];
			else
				$new[$i]['effect_3'] = '';	
				
			if ( in_array( $effects_4[$i], $options ) )
				$new[$i]['effect_4'] = $effects_4[$i];
			else
				$new[$i]['effect_4'] = '';				

			if ( in_array( $effects_5[$i], $options ) )
				$new[$i]['effect_5'] = $effects_5[$i];
			else
				$new[$i]['effect_5'] = '';

			if ( in_array( $effects_6[$i], $options ) )
				$new[$i]['effect_6'] = $effects_6[$i];
			else
				$new[$i]['effect_6'] = '';

			if ( in_array( $effects_7[$i], $options ) )
				$new[$i]['effect_7'] = $effects_7[$i];
			else
				$new[$i]['effect_7'] = '';

			if ( in_array( $effects_8[$i], $options ) )
				$new[$i]['effect_8'] = $effects_8[$i];
			else
				$new[$i]['effect_8'] = '';

			if ( in_array( $effects_9[$i], $options ) )
				$new[$i]['effect_9'] = $effects_9[$i];
			else
				$new[$i]['effect_9'] = '';


			if ( in_array( $position_0[$i], $positions_options ) )
				$new[$i]['position_0'] = $position_0[$i];
			else
				$new[$i]['position_0'] = '';
				
			if ( in_array( $position_1[$i], $positions_options ) )
				$new[$i]['position_1'] = $position_1[$i];
			else
				$new[$i]['position_1'] = '';
				
			if ( in_array( $position_2[$i], $positions_options ) )
				$new[$i]['position_2'] = $position_2[$i];
			else
				$new[$i]['position_2'] = '';	
				
			if ( in_array( $position_3[$i], $positions_options ) )
				$new[$i]['position_3'] = $position_3[$i];
			else
				$new[$i]['position_3'] = '';	
				
			if ( in_array( $position_4[$i], $positions_options ) )
				$new[$i]['position_4'] = $position_4[$i];
			else
				$new[$i]['position_4'] = '';				

			if ( in_array( $position_5[$i], $positions_options ) )
				$new[$i]['position_5'] = $position_5[$i];
			else
				$new[$i]['position_5'] = '';

			if ( in_array( $position_6[$i], $positions_options ) )
				$new[$i]['position_6'] = $position_6[$i];
			else
				$new[$i]['position_6'] = '';

			if ( in_array( $position_7[$i], $positions_options ) )
				$new[$i]['position_7'] = $position_7[$i];
			else
				$new[$i]['position_7'] = '';

			if ( in_array( $position_8[$i], $positions_options ) )
				$new[$i]['position_8'] = $position_8[$i];
			else
				$new[$i]['position_8'] = '';

			if ( in_array( $position_9[$i], $positions_options ) )
				$new[$i]['position_9'] = $position_9[$i];
			else
				$new[$i]['position_9'] = '';



			if ( in_array( $attribute_0[$i], $attribute_options ) )
				$new[$i]['attribute_0'] = $attribute_0[$i];
			else
				$new[$i]['attribute_0'] = '';
				
			if ( in_array( $attribute_1[$i], $attribute_options ) )
				$new[$i]['attribute_1'] = $attribute_1[$i];
			else
				$new[$i]['attribute_1'] = '';
				
			if ( in_array( $attribute_2[$i], $attribute_options ) )
				$new[$i]['attribute_2'] = $attribute_2[$i];
			else
				$new[$i]['attribute_2'] = '';	
				
			if ( in_array( $attribute_3[$i], $attribute_options ) )
				$new[$i]['attribute_3'] = $attribute_3[$i];
			else
				$new[$i]['attribute_3'] = '';	
				
			if ( in_array( $attribute_4[$i], $attribute_options ) )
				$new[$i]['attribute_4'] = $attribute_4[$i];
			else
				$new[$i]['attribute_4'] = '';				

			if ( in_array( $attribute_5[$i], $attribute_options ) )
				$new[$i]['attribute_5'] = $attribute_5[$i];
			else
				$new[$i]['attribute_5'] = '';

			if ( in_array( $attribute_6[$i], $attribute_options ) )
				$new[$i]['attribute_6'] = $attribute_6[$i];
			else
				$new[$i]['attribute_6'] = '';

			if ( in_array( $attribute_7[$i], $attribute_options ) )
				$new[$i]['attribute_7'] = $attribute_7[$i];
			else
				$new[$i]['attribute_7'] = '';

			if ( in_array( $attribute_8[$i], $attribute_options ) )
				$new[$i]['attribute_8'] = $attribute_8[$i];
			else
				$new[$i]['attribute_8'] = '';

			if ( in_array( $attribute_9[$i], $attribute_options ) )
				$new[$i]['attribute_9'] = $attribute_9[$i];
			else
				$new[$i]['attribute_9'] = '';



			if ( in_array( $font_weight_0[$i], $font_weight_options ) )
				$new[$i]['font_weight_0'] = $font_weight_0[$i];
			else
				$new[$i]['font_weight_0'] = '';
				
			if ( in_array( $font_weight_1[$i], $font_weight_options ) )
				$new[$i]['font_weight_1'] = $font_weight_1[$i];
			else
				$new[$i]['font_weight_1'] = '';
				
			if ( in_array( $font_weight_2[$i], $font_weight_options ) )
				$new[$i]['font_weight_2'] = $font_weight_2[$i];
			else
				$new[$i]['font_weight_2'] = '';	
				
			if ( in_array( $font_weight_3[$i], $font_weight_options ) )
				$new[$i]['font_weight_3'] = $font_weight_3[$i];
			else
				$new[$i]['font_weight_3'] = '';	
				
			if ( in_array( $font_weight_4[$i], $font_weight_options ) )
				$new[$i]['font_weight_4'] = $font_weight_4[$i];
			else
				$new[$i]['font_weight_4'] = '';				

			if ( in_array( $font_weight_5[$i], $font_weight_options ) )
				$new[$i]['font_weight_5'] = $font_weight_5[$i];
			else
				$new[$i]['font_weight_5'] = '';

			if ( in_array( $font_weight_6[$i], $font_weight_options ) )
				$new[$i]['font_weight_6'] = $font_weight_6[$i];
			else
				$new[$i]['font_weight_6'] = '';

			if ( in_array( $font_weight_7[$i], $font_weight_options ) )
				$new[$i]['font_weight_7'] = $font_weight_7[$i];
			else
				$new[$i]['font_weight_7'] = '';

			if ( in_array( $font_weight_8[$i], $font_weight_options ) )
				$new[$i]['font_weight_8'] = $font_weight_8[$i];
			else
				$new[$i]['font_weight_8'] = '';

			if ( in_array( $font_weight_9[$i], $font_weight_options ) )
				$new[$i]['font_weight_9'] = $font_weight_9[$i];
			else
				$new[$i]['font_weight_9'] = '';



			if ( in_array( $delay_0[$i], $delay_options ) )
				$new[$i]['delay_0'] = $delay_0[$i];
			else
				$new[$i]['delay_0'] = '';
				
			if ( in_array( $delay_1[$i], $delay_options ) )
				$new[$i]['delay_1'] = $delay_1[$i];
			else
				$new[$i]['delay_1'] = '';
				
			if ( in_array( $delay_2[$i], $delay_options ) )
				$new[$i]['delay_2'] = $delay_2[$i];
			else
				$new[$i]['delay_2'] = '';	
				
			if ( in_array( $delay_3[$i], $delay_options ) )
				$new[$i]['delay_3'] = $delay_3[$i];
			else
				$new[$i]['delay_3'] = '';	
				
			if ( in_array( $delay_4[$i], $delay_options ) )
				$new[$i]['delay_4'] = $delay_4[$i];
			else
				$new[$i]['delay_4'] = '';				

			if ( in_array( $delay_5[$i], $delay_options ) )
				$new[$i]['delay_5'] = $delay_5[$i];
			else
				$new[$i]['delay_5'] = '';

			if ( in_array( $delay_6[$i], $delay_options ) )
				$new[$i]['delay_6'] = $delay_6[$i];
			else
				$new[$i]['delay_6'] = '';

			if ( in_array( $delay_7[$i], $delay_options ) )
				$new[$i]['delay_7'] = $delay_7[$i];
			else
				$new[$i]['delay_7'] = '';

			if ( in_array( $delay_8[$i], $delay_options ) )
				$new[$i]['delay_8'] = $delay_8[$i];
			else
				$new[$i]['delay_8'] = '';

			if ( in_array( $delay_9[$i], $delay_options ) )
				$new[$i]['delay_9'] = $delay_9[$i];
			else
				$new[$i]['delay_9'] = '';




			$new[$i]['custom_color_0'] = stripslashes( strip_tags( $custom_color_0[$i] ) );
			$new[$i]['custom_color_1'] = stripslashes( strip_tags( $custom_color_1[$i] ) );
			$new[$i]['custom_color_2'] = stripslashes( strip_tags( $custom_color_2[$i] ) );
			$new[$i]['custom_color_3'] = stripslashes( strip_tags( $custom_color_3[$i] ) );
			$new[$i]['custom_color_4'] = stripslashes( strip_tags( $custom_color_4[$i] ) );
			$new[$i]['custom_color_5'] = stripslashes( strip_tags( $custom_color_5[$i] ) );
			$new[$i]['custom_color_6'] = stripslashes( strip_tags( $custom_color_6[$i] ) );
			$new[$i]['custom_color_7'] = stripslashes( strip_tags( $custom_color_7[$i] ) );
			$new[$i]['custom_color_8'] = stripslashes( strip_tags( $custom_color_8[$i] ) );
			$new[$i]['custom_color_9'] = stripslashes( strip_tags( $custom_color_9[$i] ) );

			$new[$i]['custom_bg_color_0'] = stripslashes( strip_tags( $custom_bg_color_0[$i] ) );
			$new[$i]['custom_bg_color_1'] = stripslashes( strip_tags( $custom_bg_color_1[$i] ) );
			$new[$i]['custom_bg_color_2'] = stripslashes( strip_tags( $custom_bg_color_2[$i] ) );
			$new[$i]['custom_bg_color_3'] = stripslashes( strip_tags( $custom_bg_color_3[$i] ) );
			$new[$i]['custom_bg_color_4'] = stripslashes( strip_tags( $custom_bg_color_4[$i] ) );
			$new[$i]['custom_bg_color_5'] = stripslashes( strip_tags( $custom_bg_color_5[$i] ) );
			$new[$i]['custom_bg_color_6'] = stripslashes( strip_tags( $custom_bg_color_6[$i] ) );
			$new[$i]['custom_bg_color_7'] = stripslashes( strip_tags( $custom_bg_color_7[$i] ) );
			$new[$i]['custom_bg_color_8'] = stripslashes( strip_tags( $custom_bg_color_8[$i] ) );
			$new[$i]['custom_bg_color_9'] = stripslashes( strip_tags( $custom_bg_color_9[$i] ) );

			$new[$i]['display_0'] = stripslashes( strip_tags( $display_0[$i] ) );
			$new[$i]['display_1'] = stripslashes( strip_tags( $display_1[$i] ) );
			$new[$i]['display_2'] = stripslashes( strip_tags( $display_2[$i] ) );
			$new[$i]['display_3'] = stripslashes( strip_tags( $display_3[$i] ) );
			$new[$i]['display_4'] = stripslashes( strip_tags( $display_4[$i] ) );
			$new[$i]['display_5'] = stripslashes( strip_tags( $display_5[$i] ) );
			$new[$i]['display_6'] = stripslashes( strip_tags( $display_6[$i] ) );
			$new[$i]['display_7'] = stripslashes( strip_tags( $display_7[$i] ) );
			$new[$i]['display_8'] = stripslashes( strip_tags( $display_8[$i] ) );
			$new[$i]['display_9'] = stripslashes( strip_tags( $display_9[$i] ) );

			$new[$i]['custom_bg_color_opacity_0'] = stripslashes( strip_tags( $custom_bg_color_opacity_0[$i] ) );
			$new[$i]['custom_bg_color_opacity_1'] = stripslashes( strip_tags( $custom_bg_color_opacity_1[$i] ) );
			$new[$i]['custom_bg_color_opacity_2'] = stripslashes( strip_tags( $custom_bg_color_opacity_2[$i] ) );
			$new[$i]['custom_bg_color_opacity_3'] = stripslashes( strip_tags( $custom_bg_color_opacity_3[$i] ) );
			$new[$i]['custom_bg_color_opacity_4'] = stripslashes( strip_tags( $custom_bg_color_opacity_4[$i] ) );
			$new[$i]['custom_bg_color_opacity_5'] = stripslashes( strip_tags( $custom_bg_color_opacity_5[$i] ) );
			$new[$i]['custom_bg_color_opacity_6'] = stripslashes( strip_tags( $custom_bg_color_opacity_6[$i] ) );
			$new[$i]['custom_bg_color_opacity_7'] = stripslashes( strip_tags( $custom_bg_color_opacity_7[$i] ) );
			$new[$i]['custom_bg_color_opacity_8'] = stripslashes( strip_tags( $custom_bg_color_opacity_8[$i] ) );
			$new[$i]['custom_bg_color_opacity_9'] = stripslashes( strip_tags( $custom_bg_color_opacity_9[$i] ) );

			$new[$i]['color_0'] = stripslashes( strip_tags( $color_0[$i] ) );
			$new[$i]['color_1'] = stripslashes( strip_tags( $color_1[$i] ) );
			$new[$i]['color_2'] = stripslashes( strip_tags( $color_2[$i] ) );
			$new[$i]['color_3'] = stripslashes( strip_tags( $color_3[$i] ) );
			$new[$i]['color_4'] = stripslashes( strip_tags( $color_4[$i] ) );
			$new[$i]['color_5'] = stripslashes( strip_tags( $color_5[$i] ) );
			$new[$i]['color_6'] = stripslashes( strip_tags( $color_6[$i] ) );
			$new[$i]['color_7'] = stripslashes( strip_tags( $color_7[$i] ) );
			$new[$i]['color_8'] = stripslashes( strip_tags( $color_8[$i] ) );
			$new[$i]['color_9'] = stripslashes( strip_tags( $color_9[$i] ) );

			$new[$i]['bg_color_0'] = stripslashes( strip_tags( $bg_color_0[$i] ) );
			$new[$i]['bg_color_1'] = stripslashes( strip_tags( $bg_color_1[$i] ) );
			$new[$i]['bg_color_2'] = stripslashes( strip_tags( $bg_color_2[$i] ) );
			$new[$i]['bg_color_3'] = stripslashes( strip_tags( $bg_color_3[$i] ) );
			$new[$i]['bg_color_4'] = stripslashes( strip_tags( $bg_color_4[$i] ) );
			$new[$i]['bg_color_5'] = stripslashes( strip_tags( $bg_color_5[$i] ) );
			$new[$i]['bg_color_6'] = stripslashes( strip_tags( $bg_color_6[$i] ) );
			$new[$i]['bg_color_7'] = stripslashes( strip_tags( $bg_color_7[$i] ) );
			$new[$i]['bg_color_8'] = stripslashes( strip_tags( $bg_color_8[$i] ) );
			$new[$i]['bg_color_9'] = stripslashes( strip_tags( $bg_color_9[$i] ) );
																					
		endif;
	}

	if ( !empty( $new ) && $new != $old )
		update_post_meta( $post_id, 'slides', $new );
	elseif ( empty($new) && $old )
		delete_post_meta( $post_id, 'slides', $old );
}

/* METABOX SLIDE OPTIONS */


add_action('admin_init', 'adtheme_fastslider_add_meta_boxes_options', 1);
function adtheme_fastslider_add_meta_boxes_options() {
	add_meta_box( 'fastslider_options', 
				  'Slider Options', 
				  'adtheme_fastslider_meta_box_options', 
				  'adt_fastslider', 
				  'normal', 
				  'high'
	);
}


function adtheme_fastslider_meta_box_options() {
	global $post;

	$adt_fastslider_shortcodes = get_post_meta($post->ID, 'adt_fastslider_shortcodes', true);
	$adt_fastslider_speed = get_post_meta($post->ID, 'adt_fastslider_speed', true);
	$adt_fastslider_autoplay = get_post_meta($post->ID, 'adt_fastslider_autoplay', true);
	$adt_fastslider_navigation = get_post_meta($post->ID, 'adt_fastslider_navigation', true);
	$adt_fastslider_pagination = get_post_meta($post->ID, 'adt_fastslider_pagination', true);
	$adt_fastslider_preload = get_post_meta($post->ID, 'adt_fastslider_preload', true);
	$adt_fastslider_autohover = get_post_meta($post->ID, 'adt_fastslider_autohover', true);
	$adt_fastslider_loop = get_post_meta($post->ID, 'adt_fastslider_loop', true);
	$adt_fastslider_pause = get_post_meta($post->ID, 'adt_fastslider_pause', true);
	$adt_fastslider_transition = get_post_meta($post->ID, 'adt_fastslider_transition', true);
	$adt_fastslider_bg_color_pattern = get_post_meta($post->ID, 'adt_fastslider_bg_color_pattern', true);
	$adt_fastslider_bg_opacity_pattern = get_post_meta($post->ID, 'adt_fastslider_bg_opacity_pattern', true);
	$adt_fastslider_custom_style = get_post_meta($post->ID, 'adt_fastslider_custom_style', true);
	$adt_fastslider_color_np = get_post_meta($post->ID, 'adt_fastslider_color_np', true);
	$adt_fastslider_navigation_style = get_post_meta($post->ID, 'adt_fastslider_navigation_style', true);
	$adt_fastslider_pagination_style = get_post_meta($post->ID, 'adt_fastslider_pagination_style', true);
	$adt_fastslider_preload_bg_color = get_post_meta($post->ID, 'adt_fastslider_preload_bg_color', true);
	$adt_fastslider_preload_spinner_color = get_post_meta($post->ID, 'adt_fastslider_preload_spinner_color', true);
	
	wp_nonce_field( 'adtheme_fastslider_meta_box_options_nonce', 'adtheme_fastslider_meta_box_options_nonce' );
	
	?>
    <div class="adt-fastslider-row">
    
    	<div class="adt-slider-shorcodes-name">
        
        	<h2><?php echo __('Slider Shortcode (copy and paste)','fastslider'); ?></h2>
        	<input type="text" id="adt_fastslider_speed" name="adt_fastslider_speed" value='[adt_fastslider id="<?php echo get_the_id(); ?>"]' size="25" readonly>
        
        </div>
        
        <div class="adt-slider-options">
        	<h1><?php echo __('Slider Options','fastslider'); ?></h1>
            
        	<div class="adt-slider-options-speed">
        
        	<h2><?php echo __('Speed (ms)','fastslider'); ?></h2>
            <input type="text" id="adt_fastslider_speed" name="adt_fastslider_speed" value="<?php echo esc_attr( $adt_fastslider_speed ); ?>" size="25">

			</div>

        	<div class="adt-slider-options-pause">
        
        	<h2><?php echo __('Pause (ms)','fastslider'); ?></h2>
            <input type="text" id="adt_fastslider_pause" name="adt_fastslider_pause" value="<?php echo esc_attr( $adt_fastslider_pause ); ?>" size="25">

			</div>

        	<div class="adt-slider-options-autoplay">
        
                <h2><?php echo __('Autoplay','fastslider'); ?></h2>
                <select id="adt_fastslider_autoplay" name="adt_fastslider_autoplay">
                <option value="true" <?php if ($adt_fastslider_autoplay == 'true') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                <option value="false" <?php if ($adt_fastslider_autoplay == 'false') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                </select>
        
			</div>

			<div class="adt-line"></div>

        	<div class="adt-slider-options-navigation">
        
                <h2><?php echo __('Navigation','fastslider'); ?></h2>
                <select id="adt_fastslider_navigation" name="adt_fastslider_navigation">
                <option value="true" <?php if ($adt_fastslider_navigation == 'true') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                <option value="false" <?php if ($adt_fastslider_navigation == 'false') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                </select>
        
			</div>
            
        	<div class="adt-slider-options-pagination">
        
                <h2><?php echo __('Pagination','fastslider'); ?></h2>
                <select id="adt_fastslider_pagination" name="adt_fastslider_pagination">
                <option value="true" <?php if ($adt_fastslider_pagination == 'true') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                <option value="false" <?php if ($adt_fastslider_pagination == 'false') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                </select>
        
			</div>            

        	<div class="adt-slider-options-preload">
        
                <h2><?php echo __('Preload','fastslider'); ?></h2>
                <select id="adt_fastslider_preload" name="adt_fastslider_preload">
                    <option value="spinner-plane" <?php if ($adt_fastslider_preload == 'spinner-plane') { echo 'selected'; }?>><?php echo __('Spinner plane','fastslider'); ?></option>
                    <option value="spinner-wave" <?php if ($adt_fastslider_preload == 'spinner-wave') { echo 'selected'; }?>><?php echo __('Spinner wave','fastslider'); ?></option>
                    <option value="spinner-bounce" <?php if ($adt_fastslider_preload == 'spinner-bounce') { echo 'selected'; }?>><?php echo __('Spinner bounce','fastslider'); ?></option>
                    <option value="spinner-cubes" <?php if ($adt_fastslider_preload == 'spinner-cubes') { echo 'selected'; }?>><?php echo __('Spinner cubes','fastslider'); ?></option>
                    <option value="spinner-pulse" <?php if ($adt_fastslider_preload == 'spinner-pulse') { echo 'selected'; }?>><?php echo __('Spinner pulse','fastslider'); ?></option>
                    <option value="spinner-dots" <?php if ($adt_fastslider_preload == 'spinner-dots') { echo 'selected'; }?>><?php echo __('Spinner dots','fastslider'); ?></option>
                    <option value="spinner-three-bounce" <?php if ($adt_fastslider_preload == 'spinner-three-bounce') { echo 'selected'; }?>><?php echo __('Spinner three bounce','fastslider'); ?></option>
                    <option value="spinner-circle" <?php if ($adt_fastslider_preload == 'spinner-circle') { echo 'selected'; }?>><?php echo __('Spinner circle','fastslider'); ?></option>
                    <option value="off" <?php if ($adt_fastslider_preload == 'off') { echo 'selected'; }?>><?php echo __('Off (Disable Preload)','fastslider'); ?></option>               
                </select>
        
			</div>

			<div class="adt-line"></div>

        	<div class="adt-slider-options-autoHover">
        
                <h2><?php echo __('Auto Hover','fastslider'); ?></h2>
                <select id="adt_fastslider_autohover" name="adt_fastslider_autohover">
                <option value="true" <?php if ($adt_fastslider_autohover == 'true') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                <option value="false" <?php if ($adt_fastslider_autohover == 'false') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                </select>
        
			</div>

        	<div class="adt-slider-options-loop">
        
                <h2><?php echo __('Loop','fastslider'); ?></h2>
                <select id="adt_fastslider_loop" name="adt_fastslider_loop">
                <option value="true" <?php if ($adt_fastslider_loop == 'true') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                <option value="false" <?php if ($adt_fastslider_loop == 'false') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                </select>
        
			</div>
 
        	<div class="adt-slider-options-transition">
        
                <h2><?php echo __('Transition','fastslider'); ?></h2>
                <select id="adt_fastslider_transition" name="adt_fastslider_transition">
                <option value="fade" <?php if ($adt_fastslider_transition == 'on') { echo 'fade'; }?>><?php echo __('Fade','fastslider'); ?></option>
                <option value="horizontal" <?php if ($adt_fastslider_transition == 'horizontal') { echo 'selected'; }?>><?php echo __('Horizontal','fastslider'); ?></option>
                <option value="vertical" <?php if ($adt_fastslider_transition == 'vertical') { echo 'selected'; }?>><?php echo __('Vertical','fastslider'); ?></option>
                </select>
        
			</div> 

			<div class="adt-line adt-last"></div>
        
        	<div class="adt-slider-options-style">
        		<h1><?php echo __('Slider Style','fastslider'); ?></h1>
                
                <div class="adt-slider-options-custom-style">
                
                    <h2><?php echo __('Custom Style for Pattern','fastslider'); ?></h2>
                    
                    <select id="adt_fastslider_custom_style" name="adt_fastslider_custom_style">
                        <option value="on" <?php if ($adt_fastslider_custom_style == 'on') { echo 'selected'; }?>><?php echo __('On','fastslider'); ?></option>
                        <option value="off" <?php if ($adt_fastslider_custom_style == 'off') { echo 'selected'; }?>><?php echo __('Off','fastslider'); ?></option>
                    </select>
                
                </div>
                
                <div class="adt-slider-options-bg-color">
                        
                    <h2><?php echo __('Pattern Background Color','fastslider'); ?></h2>
                    <input class="color-field-saved" type="text" name="adt_fastslider_bg_color_pattern" value="<?php echo $adt_fastslider_bg_color_pattern; ?>"/>
       			
                </div>
                
                 <div class="adt-slider-options-opacity">
                
                    <h2><?php echo __('Opacity (value 0.1 to 1)','fastslider'); ?></h2>
                    <input type="text" id="adt_fastslider_bg_opacity_pattern" name="adt_fastslider_bg_opacity_pattern" value="<?php echo esc_attr( $adt_fastslider_bg_opacity_pattern ); ?>" size="25">
        
        		</div>
                
                <div class="adt-line"></div>
                
                 <div class="adt-slider-options-pagination">
        
                    <h2><?php echo __('Pagination','fastslider'); ?></h2>
                    <select id="adt_fastslider_pagination_style" name="adt_fastslider_pagination_style">
                        <option value="square" <?php if ($adt_fastslider_pagination_style == 'square') { echo 'selected'; }?>><?php echo __('Square','fastslider'); ?></option>
                        <option value="round" <?php if ($adt_fastslider_pagination_style == 'round') { echo 'selected'; }?>><?php echo __('Round','fastslider'); ?></option>
                    </select> 
                
                 </div>
                
                 <div class="adt-slider-options-navigation">
                
                    <h2><?php echo __('Navigation','fastslider'); ?></h2>
                    <select id="adt_fastslider_navigation_style" name="adt_fastslider_navigation_style">
                        <option value="square" <?php if ($adt_fastslider_navigation_style == 'square') { echo 'selected'; }?>><?php echo __('Square','fastslider'); ?></option>
                        <option value="round" <?php if ($adt_fastslider_navigation_style == 'round') { echo 'selected'; }?>><?php echo __('Round','fastslider'); ?></option>
                    </select>
                
                 </div>
                
                <div class="adt-slider-options-color-np">
                
                    <h2><?php echo __('Color Navigation/Pagination','fastslider'); ?></h2>
                    <input class="color-field-saved" type="text" name="adt_fastslider_color_np" value="<?php echo $adt_fastslider_color_np; ?>"/>
                 
                </div> 
                
                <div class="adt-line"></div>
                
                <div class="adt-slider-options-preload-bg-color">
                        
                    <h2><?php echo __('Preload Background Color','fastslider'); ?></h2>
                    <input class="color-field-saved" type="text" name="adt_fastslider_preload_bg_color" value="<?php echo $adt_fastslider_preload_bg_color; ?>"/>
       			
                </div>
                
                <div class="adt-slider-options-preload-spinner-color">
                        
                    <h2><?php echo __('Preload Spinner Color','fastslider'); ?></h2>
                    <input class="color-field-saved" type="text" name="adt_fastslider_preload_spinner_color" value="<?php echo $adt_fastslider_preload_spinner_color; ?>"/>
       			
                </div>
                
                
                
                <div class="adt-clear"></div>
                                           
        	</div>
        
        </div>
            
    </div>        
<?php }

add_action('save_post', 'adtheme_fastslider_meta_box_options_save');
function adtheme_fastslider_meta_box_options_save($post_id) {   
	if ( ! isset( $_POST['adtheme_fastslider_meta_box_options_nonce'] ) ||
	! wp_verify_nonce( $_POST['adtheme_fastslider_meta_box_options_nonce'], 'adtheme_fastslider_meta_box_options_nonce' ) )
		return;
	
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;
	
	if (!current_user_can('edit_post', $post_id))
		return;
	
  	$adt_fastslider_speed = sanitize_text_field( $_POST['adt_fastslider_speed'] );
  	update_post_meta( $post_id, 'adt_fastslider_speed', $adt_fastslider_speed );	

  	$adt_fastslider_autoplay = sanitize_text_field( $_POST['adt_fastslider_autoplay'] );
  	update_post_meta( $post_id, 'adt_fastslider_autoplay', $adt_fastslider_autoplay );

  	$adt_fastslider_navigation = sanitize_text_field( $_POST['adt_fastslider_navigation'] );
  	update_post_meta( $post_id, 'adt_fastslider_navigation', $adt_fastslider_navigation );
	
  	$adt_fastslider_pagination = sanitize_text_field( $_POST['adt_fastslider_pagination'] );
  	update_post_meta( $post_id, 'adt_fastslider_pagination', $adt_fastslider_pagination );	
	
  	$adt_fastslider_preload = sanitize_text_field( $_POST['adt_fastslider_preload'] );
  	update_post_meta( $post_id, 'adt_fastslider_preload', $adt_fastslider_preload );		
	
  	$adt_fastslider_autohover = sanitize_text_field( $_POST['adt_fastslider_autohover'] );
  	update_post_meta( $post_id, 'adt_fastslider_autohover', $adt_fastslider_autohover );		

  	$adt_fastslider_loop = sanitize_text_field( $_POST['adt_fastslider_loop'] );
  	update_post_meta( $post_id, 'adt_fastslider_loop', $adt_fastslider_loop );	
	
  	$adt_fastslider_pause = sanitize_text_field( $_POST['adt_fastslider_pause'] );
  	update_post_meta( $post_id, 'adt_fastslider_pause', $adt_fastslider_pause );	
	
  	$adt_fastslider_transition = sanitize_text_field( $_POST['adt_fastslider_transition'] );
  	update_post_meta( $post_id, 'adt_fastslider_transition', $adt_fastslider_transition );			

  	$adt_fastslider_bg_color_pattern = sanitize_text_field( $_POST['adt_fastslider_bg_color_pattern'] );
  	update_post_meta( $post_id, 'adt_fastslider_bg_color_pattern', $adt_fastslider_bg_color_pattern );

  	$adt_fastslider_bg_opacity_pattern = sanitize_text_field( $_POST['adt_fastslider_bg_opacity_pattern'] );
  	update_post_meta( $post_id, 'adt_fastslider_bg_opacity_pattern', $adt_fastslider_bg_opacity_pattern );

  	$adt_fastslider_custom_style = sanitize_text_field( $_POST['adt_fastslider_custom_style'] );
  	update_post_meta( $post_id, 'adt_fastslider_custom_style', $adt_fastslider_custom_style );

  	$adt_fastslider_color_np = sanitize_text_field( $_POST['adt_fastslider_color_np'] );
  	update_post_meta( $post_id, 'adt_fastslider_color_np', $adt_fastslider_color_np );
	
  	$adt_fastslider_navigation_style = sanitize_text_field( $_POST['adt_fastslider_navigation_style'] );
  	update_post_meta( $post_id, 'adt_fastslider_navigation_style', $adt_fastslider_navigation_style );
	
  	$adt_fastslider_pagination_style = sanitize_text_field( $_POST['adt_fastslider_pagination_style'] );
  	update_post_meta( $post_id, 'adt_fastslider_pagination_style', $adt_fastslider_pagination_style );		

  	$adt_fastslider_preload_bg_color = sanitize_text_field( $_POST['adt_fastslider_preload_bg_color'] );
  	update_post_meta( $post_id, 'adt_fastslider_preload_bg_color', $adt_fastslider_preload_bg_color );	

  	$adt_fastslider_preload_spinner_color = sanitize_text_field( $_POST['adt_fastslider_preload_spinner_color'] );
  	update_post_meta( $post_id, 'adt_fastslider_preload_spinner_color', $adt_fastslider_preload_spinner_color );	
	
}

add_action('admin_init', 'adtheme_fastslider_add_meta_boxes_custom_code', 1);
function adtheme_fastslider_add_meta_boxes_custom_code() {
	add_meta_box( 'fastslider_custom_code', 
				  'Custom Code', 
				  'adtheme_fastslider_meta_box_custom_code', 
				  'adt_fastslider', 
				  'normal', 
				  'low'
	);
}

function adtheme_fastslider_meta_box_custom_code(){
	global $post;

	$adt_fastslider_custom_css = get_post_meta($post->ID, 'adt_fastslider_custom_css', true);
	$adt_fastslider_custom_js = get_post_meta($post->ID, 'adt_fastslider_custom_js', true);	
	wp_nonce_field( 'adtheme_fastslider_meta_box_custom_code_nonce', 'adtheme_fastslider_meta_box_custom_code_nonce' );
?>	
	
    <h2><?php echo __('Custom CSS','fastslider'); ?></h2>
    <textarea type="textarea" id="adt_fastslider_custom_css" name="adt_fastslider_custom_css" rows="4" cols="50"><?php echo esc_attr( $adt_fastslider_custom_css ); ?></textarea>
     
    <h2><?php echo __('Custom JS','fastslider'); ?></h2>
    <textarea type="textarea" id="adt_fastslider_custom_js" name="adt_fastslider_custom_js" rows="4" cols="50"><?php echo esc_attr( $adt_fastslider_custom_js ); ?></textarea>
    
    
    
<?php	
}

add_action('save_post', 'adtheme_fastslider_meta_box_custom_code_save');
function adtheme_fastslider_meta_box_custom_code_save($post_id) {   
	if ( ! isset( $_POST['adtheme_fastslider_meta_box_custom_code_nonce'] ) ||
	! wp_verify_nonce( $_POST['adtheme_fastslider_meta_box_custom_code_nonce'], 'adtheme_fastslider_meta_box_custom_code_nonce' ) )
		return;
	
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;
	
	if (!current_user_can('edit_post', $post_id))
		return;
	
  	$adt_fastslider_custom_css = sanitize_text_field( $_POST['adt_fastslider_custom_css'] );
  	update_post_meta( $post_id, 'adt_fastslider_custom_css', $adt_fastslider_custom_css );	

  	$adt_fastslider_custom_js = sanitize_text_field( $_POST['adt_fastslider_custom_js'] );
  	update_post_meta( $post_id, 'adt_fastslider_custom_js', $adt_fastslider_custom_js );
	
}