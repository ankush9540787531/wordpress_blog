<?php
/*
Description: functions.php
Author: AD-THEME
*/

/**************************************************************************/
/*********************** REGISTER CUSTOM POST TYPE ************************/
/**************************************************************************/

add_action( 'init', 'adf_fs_register_posttype' );

function adf_fs_register_posttype() {

	$labels = array(
		'name'               => __('FAST SLIDER', 'fastslider'),
		'singular_name'      => __('FAST SLIDER', 'fastslider'),
		'add_new'            => __('Add New SLIDER', 'fastslider'),
		'add_new_item'       => __('Add New SLIDER', 'fastslider'),
		'edit_item'          => __('Edit SLIDER', 'fastslider'),
		'new_item'           => __('New SLIDER', 'fastslider'),
		'all_items'          => __('All SLIDER', 'fastslider'),
		'view_item'          => __('View SLIDER', 'fastslider'),
		'search_items'       => __('Search SLIDER', 'fastslider'),
		'not_found'          => __('No SLIDER found', 'fastslider'),
		'not_found_in_trash' => __('No SLIDER found in Trash', 'fastslider'),
		'parent_item_colon'  => '',
		'menu_name'          => __('FAST SLIDER', 'fastslider')
	  );
	
	  $args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'adt_fastslider' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'show_in_admin_bar'	 => false,
		'menu_position'      => null,		
		'menu_icon'			 => plugins_url( 'fastslider/assets/img/fastslider.png'),
		'supports'           => array('title' )
	  );
	
	  register_post_type( 'adt_fastslider', $args );

}

/**************************************************************************/
/************* CHANGE NAME BUTTON STATUS CUSTOM POST TYPE *****************/
/**************************************************************************/

add_filter( 'gettext', 'adt_fastslider_change_name_button_status', 10, 2 );

function adt_fastslider_change_name_button_status( $translation, $text ) {
	
	global $post_type;
	
	if('adt_fastslider' == $post_type) {
		if ( $text == 'Publish' )
    		return __('Save Slider','fastslider');
			
		if ( $text == 'Update' )
    		return __('Update Slider','fastslider');
			
		if ( $text == 'Move to Trash' )
    		return __('Delete Slider','fastslider');				
	}
	
	return $translation;
}

/**
 * Try to convert an attachment URL into a post ID.
 *
 * @since 4.0.0
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string $url The URL to resolve.
 * @return int The found post ID.
 */
function adt_fastgallery_attachment_url_to_postid( $url ) {
    global $wpdb;

    $dir = wp_upload_dir();
    $path = $url;

    if ( 0 === strpos( $path, $dir['baseurl'] . '/' ) ) {
        $path = substr( $path, strlen( $dir['baseurl'] . '/' ) );
    }

    $sql = $wpdb->prepare(
        "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value = %s",
        $path
    );
    $post_id = $wpdb->get_var( $sql );
    if ( ! empty( $post_id ) ) {
        return (int) $post_id;
    }
}

/**************************************************************************/
/*********************** THUMBNAILS FUNCTION ******************************/
/**************************************************************************/

function adt_fastslider_add_image_sizes() {
	
	add_image_size( 'adt_fastslider', 1920, 800, true );

}

add_action( 'init', 'adt_fastslider_add_image_sizes' );

/**************************************************************************/
/******************* HIDE PERMALINK CUSTOM POST TYPE **********************/
/**************************************************************************/

add_filter('get_sample_permalink_html', 'adt_fastgallery_hide_permalinks', 10, 5);

function adt_fastgallery_hide_permalinks($return, $post_id, $new_title, $new_slug, $post)
{
    if($post->post_type == 'adt_fastslider') {
        return '';
    }
    return $return;
}

/**************************************************************************/
/******************* UPDATE MESSAGE CUSTOM POST TYPE **********************/
/**************************************************************************/

function adt_fastgallery_update_messages( $messages )
{
        global $post;
		if($post->post_type == 'adt_fastslider') {
				$post_ID = $post->ID;
				$post_type = get_post_type( $post_ID );
		
				$obj = get_post_type_object( $post_type );
				$singular = $obj->labels->singular_name;
		
				$messages[$post_type] = array(
						0 => '', // Unused. Messages start at index 1.
						1 => sprintf( __( 'Slider updated.' ), esc_attr( $singular ), esc_url( get_permalink( $post_ID ) ), strtolower( $singular ) ),
						2 => __( 'Slider updated.', 'fastslider' ),
						3 => __( 'Slider deleted.', 'fastslider' ),
						4 => sprintf( __( 'Slider updated.', 'fastslider' ), esc_attr( $singular ) ),
						5 => isset( $_GET['revision']) ? sprintf( __('%2$s restored to revision from %1$s', 'fastslider' ), wp_post_revision_title( (int) $_GET['revision'], false ), esc_attr( $singular ) ) : false,
						6 => sprintf( __( 'Slider published.'), $singular, esc_url( get_permalink( $post_ID ) ), strtolower( $singular ) ),
						7 => sprintf( __( 'Slider saved.', 'fastslider' ), esc_attr( $singular ) ),
						8 => sprintf( __( 'Slider submitted.'), $singular, esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ), strtolower( $singular ) ),
						9 => sprintf( __( 'Slider scheduled for: <strong>%s</strong>.' ), $singular, date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ), strtolower( $singular ) ),
						10 => sprintf( __( 'Slider draft updated. '), $singular, esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ), strtolower( $singular ) )
				);
		
				return $messages;
		}
		return $messages;
}
add_filter( 'post_updated_messages', 'adt_fastgallery_update_messages' );

/**************************************************************************/
/********************** FUNCTION ADD COLUMNS ******************************/
/**************************************************************************/

add_filter('manage_adt_fastslider_posts_columns', 'adt_fastslider_columns_head');
add_action('manage_adt_fastslider_posts_custom_column', 'adt_fastslider_columns_content', 10, 2);

function adt_fastslider_columns_head($defaults) {
    $defaults['shortcodes'] = 'Shortcode';
    return $defaults;
}

function adt_fastslider_columns_content($column_name, $post_ID) {
    if ($column_name == 'shortcodes') {
		echo '[adt_fastslider id="'.get_the_id().'"]';
    }
}

function add_adt_fastslider_columns($columns) {
    return array_merge($columns, 
              array('shortcodes' => __('Shortcodes')));
}
add_filter('manage_adt_fastslider_posts_columns' , 'add_adt_fastslider_columns');

function set_adt_fastslider_columns($columns) {
    return array(
        'cb' => '<input type="checkbox" />',
        'title' => __('Title'),
		'shortcodes' => __('Shortcodes'),
        'date' => __('Date'),
    );
}
add_filter('manage_adt_fastslider_posts_columns' , 'set_adt_fastslider_columns');

/**************************************************************************/
/******************************** RGBA ************************************/
/**************************************************************************/

function adt_fastslider_shex2rgb($hex) {

   $hex = str_replace("#", "", $hex);

if(strlen($hex) == 3) {
		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);
	return $rgb;
}


/**************************************************************************/
/***********************VISUAL COMPOSER ADDON *****************************/
/**************************************************************************/

class vc_fastslider_class {
		function __construct() {
	
			add_action( 'init', array( $this, 'integrate_vc_fastslider_WithVC' ) );
			add_shortcode( 'adt_fastslider', array( $this, 'vc_fastslider_function' ) );
	
		}
	 
		public function integrate_vc_fastslider_WithVC() {
			if ( ! defined( 'WPB_VC_VERSION' ) ) {
				return;
			}
			
			$vc_fastslider_fast_slider = array();
			$vc_fastslider_query = 'post_type=Post&post_status=publish&post_type=adt_fastslider&posts_per_page=-1';
			$vc_fastslider_loop = new WP_Query($vc_fastslider_query);
			if($vc_fastslider_loop) { 
			while ( $vc_fastslider_loop->have_posts() ) : $vc_fastslider_loop->the_post();
			
				$vc_fastslider_title = get_the_title();
				if($vc_fastslider_title == '') { $vc_fastslider_title = __('Slider with No Title','fastslider'); }
				$vc_fastslider_id = get_the_id(); 
				$vc_fastslider_title = __('ID','fastslider') . ': ' . $vc_fastslider_id . ' - ' . __('Title','fastslider'). ': ' . $vc_fastslider_title;
				$vc_fastslider_fast_slider[$vc_fastslider_title] = $vc_fastslider_id;

			endwhile;
			}  
			      		
			vc_map( array(
				"name" => __("Fast Slider", 'fastslider'),
				"description" => __("ADD Your Fast Slider", 'fastslider'),
				"base" => "adt_fastslider",
				"class" => "",
				"icon" => plugins_url('fastslider/assets/img/fastslider_vc.png'),
				"category" => __('Fast Slider', 'js_composer'),
				"params" => array(			  
					array(
					  "type" => "dropdown",
					  "class" => "",
					  "heading" => __("Fast Slider", 'fastslider'),
					  "param_name" => "id",
					  "value" => $vc_fastslider_fast_slider,
					  "admin_label" => true				   
					),					  			  		  			  
				)  
			)		  			  			  			  			  			  
		  );
		}	
		
}
new vc_fastslider_class();