<?php
/*
Plugin Name: Fast Slider
Plugin URI: http://plugins.ad-theme.com/fastslider
Description: Fast Slider - Build your slider in one minute. Save your time.
Author: AD-THEME
Version: 1.0
Author URI: http://codecanyon.net/user/ad-theme/portfolio/?ref=ad-theme
*/

// Basic plugin definitions 
define ('ADT_FS_PLG_NAME', 'fastslider');
define( 'ADT_FS_PLG_VERSION', '1.0' );
define( 'ADT_FS_URL', WP_PLUGIN_URL . '/' . str_replace( basename(__FILE__), '', plugin_basename(__FILE__) ));
define( 'ADT_FS_DIR', WP_PLUGIN_DIR . '/' . str_replace( basename(__FILE__), '', plugin_basename(__FILE__) ));

// Language
add_action('init', 'adt_fastslider_language');
function adt_fastslider_language() {
	load_plugin_textdomain('fastslider', false, ADT_FS_DIR . '/languages/'); 
}

// Load main files

require_once(ADT_FS_DIR.'assets/assets.php');
require_once(ADT_FS_DIR.'inc/admin/metabox.php'); 
require_once(ADT_FS_DIR.'inc/admin/metabox-functions.php');
require_once(ADT_FS_DIR.'inc/functions.php');
require_once(ADT_FS_DIR.'inc/slider.php');  